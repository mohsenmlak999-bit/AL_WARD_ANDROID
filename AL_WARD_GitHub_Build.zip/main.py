# AL_WARD_v200 — تصميم جديد كامل ("Rose Noir") مع الإبقاء على كل منطق Supabase
import os
import json
import io
import math
import time
import uuid
import hashlib
import threading
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import requests

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.graphics import (
    Color, RoundedRectangle, Ellipse, Rectangle, Line, Triangle,
    StencilPush, StencilPop, StencilUse, StencilUnUse,
    PushMatrix, PopMatrix, Rotate,
)
from kivy.graphics.texture import Texture
from kivy.properties import StringProperty, ListProperty, NumericProperty
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.screenmanager import Screen, ScreenManager, FadeTransition
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.anchorlayout import AnchorLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView
from kivy.uix.widget import Widget
from kivy.uix.popup import Popup
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.image import Image, AsyncImage
from kivy.utils import get_color_from_hex, platform

try:
    import arabic_reshaper
    from bidi.algorithm import get_display
    def ar(text):
        return get_display(arabic_reshaper.reshape(str(text)))
except Exception:
    def ar(text):
        return str(text)

SUPABASE_URL = "https://enupzygislseoowiqbzf.supabase.co"
SUPABASE_KEY = "sb_publishable_5tSTskZO2kWeUOTg1H-6vA_WPeS7AHm"

FONT_CANDIDATES = [
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts", "NotoNaskhArabic-VariableFont_wght.ttf"),
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts", "NotoNaskhArabic-Regular.ttf"),
    "/storage/emulated/0/Download/NotoNaskhArabic-VariableFont_wght.ttf",
    "/storage/emulated/0/Download/NotoNaskhArabic-Regular.ttf",
    "/storage/emulated/0/Download/NotoNaskhArabicUI-Regular.ttf",
    "/storage/emulated/0/Download/NotoSansArabic-Regular.ttf",
    "/system/fonts/NotoNaskhArabic-Regular.ttf",
    "/system/fonts/NotoNaskhArabicUI-Regular.ttf",
    "/system/fonts/NotoSansArabic-Regular.ttf",
    "/system/fonts/NotoSansArabicUI-Regular.ttf",
]
FONT_PATH = next((p for p in FONT_CANDIDATES if os.path.exists(p)), "Roboto")

DATA_FILE = os.path.join(
    os.environ.get("ANDROID_PRIVATE", os.path.dirname(os.path.abspath(__file__))),
    "alward_data.json")
DEFAULT_DATA = {
    "username": "mohsen12",
    "status": "...",
    "join": "2025/09/16",
    "avatar": "",
}



# ═══════════════════════════════════════════════════════════════
#  الثيم الجديد — "Rose Noir"
# ═══════════════════════════════════════════════════════════════
def hexa(h, a=1.0):
    c = list(get_color_from_hex(h))
    c[3] = a
    return tuple(c)


BG = hexa("#07050D")
BG_TOP = hexa("#1D1131")
PANEL = hexa("#120D1D")
CARD = hexa("#1A1328")
CARD2 = hexa("#251C38")
FIELD = hexa("#140E21")
BORDER = (1, 1, 1, .08)
ACCENT = hexa("#F2517F")
ACCENT_END = hexa("#B8337E")
GOLD = hexa("#E8C27A")
VIOLET = hexa("#6B3FA0")
HERO_A = hexa("#4B2A7A")
HERO_B = hexa("#B8337E")
TEXT = hexa("#F6F0F8")
MUTED = hexa("#9A8FAE")
GREEN = hexa("#2FD38A")
RED = hexa("#7E3035")
BLUE = hexa("#4A2F73")
WHITE = (1, 1, 1, 1)
DANGER_FILL = (1, .36, .45, .12)
DANGER_BORDER = (1, .36, .45, .38)
DANGER_TXT = hexa("#FF7A8C")
AVATAR_COLORS = [
    hexa("#C2416B"), hexa("#7C4DBA"), hexa("#2E8B9A"),
    hexa("#D9822B"), hexa("#4A6FD8"), hexa("#2FA27A"),
]

Window.clearcolor = BG

_TEX = {}


def gradient(name, stops, vertical=False, steps=48):
    """يرسم تدرجاً لونياً كـ Texture (أفقي أو عمودي من الأسفل للأعلى)."""
    if name in _TEX:
        return _TEX[name]
    pix = bytearray()
    for i in range(steps):
        t = i / (steps - 1)
        seg = t * (len(stops) - 1)
        k = min(int(seg), len(stops) - 2)
        f = seg - k
        a, b = stops[k], stops[k + 1]
        for c in range(4):
            pix.append(int(255 * (a[c] + (b[c] - a[c]) * f)))
    size = (1, steps) if vertical else (steps, 1)
    tex = Texture.create(size=size, colorfmt="rgba")
    tex.blit_buffer(bytes(pix), colorfmt="rgba", bufferfmt="ubyte")
    tex.mag_filter = "linear"
    tex.min_filter = "linear"
    _TEX[name] = tex
    return tex


def accent_tex():
    return gradient("accent", [ACCENT, ACCENT_END])


def paint_background(w):
    """خلفية الشاشة: تدرج بنفسجي داكن مع توهجات وردية وبنفسجية ناعمة."""
    layers = []
    with w.canvas.before:
        Color(1, 1, 1, 1)
        bg = Rectangle(texture=gradient("bg", [BG, BG_TOP], vertical=True),
                       pos=w.pos, size=w.size)
        for which, col in enumerate((ACCENT, VIOLET)):
            for i in range(6):
                Color(col[0], col[1], col[2], .032)
                layers.append((which, i, Ellipse()))

    def sync(*_):
        bg.pos, bg.size = w.pos, w.size
        for which, i, e in layers:
            base = w.width * (.95 if which == 0 else 1.25)
            r = base * (1 - i * .15) / 2
            if which == 0:
                cx, cy = w.right - w.width * .08, w.top - w.width * .10
            else:
                cx, cy = w.x + w.width * .05, w.y + w.height * .12
            e.pos = (cx - r, cy - r)
            e.size = (2 * r, 2 * r)

    w.bind(pos=sync, size=sync)
    sync()


def _rr(x, y, w, h, r):
    r = max(.5, min(r, w / 2.0, h / 2.0))
    return (x, y, max(w, 1), max(h, 1), r)


class Card(BoxLayout):
    """بطاقة بحواف دائرية وإطار خفيف. تقبل تدرجاً لونياً اختيارياً."""

    def __init__(self, fill=CARD, border=BORDER, radius=18, texture=None, **kw):
        super().__init__(**kw)
        self._radius = dp(radius)
        with self.canvas.before:
            self._fillc = Color(*(WHITE if texture is not None else fill))
            shape_kw = {"texture": texture} if texture is not None else {}
            self._shape = RoundedRectangle(
                pos=self.pos, size=self.size,
                radius=[self._radius], **shape_kw)
            if border:
                Color(*border)
                self._line = Line(
                    rounded_rectangle=_rr(self.x, self.y, self.width, self.height, self._radius),
                    width=1)
            else:
                self._line = None
        self._base_fill = fill
        self._has_tex = texture is not None
        self.bind(pos=self._sync_card, size=self._sync_card)

    def _sync_card(self, *_):
        self._shape.pos = self.pos
        self._shape.size = self.size
        if self._line is not None:
            self._line.rounded_rectangle = _rr(
                self.x, self.y, self.width, self.height, self._radius)

    def set_pressed(self, down):
        if self._has_tex or self._fillc is None:
            return
        if down:
            c = self._base_fill
            self._fillc.rgba = (min(1, c[0] + .06), min(1, c[1] + .06),
                                min(1, c[2] + .08), c[3])
        else:
            self._fillc.rgba = self._base_fill



class LongPressMixin:
    """ضغطة مطوّلة: يستدعي long_cb(widget) بعد 0.55 ثانية دون تحريك الإصبع."""
    long_cb = None
    long_fired = False
    _lp_ev = None
    _lp_pos = (0, 0)

    def on_touch_down(self, touch):
        if self.long_cb is not None and self.collide_point(*touch.pos):
            self.long_fired = False
            self._lp_pos = touch.pos
            self._lp_cancel()
            self._lp_ev = Clock.schedule_once(self._lp_fire, .55)
        return super().on_touch_down(touch)

    def on_touch_move(self, touch):
        if self._lp_ev is not None and (
                abs(touch.x - self._lp_pos[0]) > dp(10) or abs(touch.y - self._lp_pos[1]) > dp(10)):
            self._lp_cancel()
        return super().on_touch_move(touch)

    def on_touch_up(self, touch):
        self._lp_cancel()
        return super().on_touch_up(touch)

    def _lp_cancel(self):
        if self._lp_ev is not None:
            self._lp_ev.cancel()
            self._lp_ev = None

    def _lp_fire(self, _dt):
        self._lp_ev = None
        self.long_fired = True
        if self.long_cb is not None:
            self.long_cb(self)


class PressBox(LongPressMixin, BoxLayout):
    pass


class ListRow(LongPressMixin, ButtonBehavior, Card):
    def __init__(self, **kw):
        super().__init__(**kw)
        self.bind(state=lambda *_: self.set_pressed(self.state == "down"))


class GoldButton(Button):
    """الزر الرئيسي: تدرج وردي مع توهج خفيف."""

    def __init__(self, **kwargs):
        kwargs.setdefault("background_normal", "")
        kwargs.setdefault("background_down", "")
        kwargs.setdefault("background_color", (0, 0, 0, 0))
        kwargs.setdefault("color", WHITE)
        kwargs.setdefault("font_name", FONT_PATH)
        kwargs.setdefault("font_size", "15sp")
        if isinstance(kwargs.get("text"), str):
            kwargs["text"] = ar(kwargs["text"])
        super().__init__(**kwargs)
        with self.canvas.before:
            Color(ACCENT[0], ACCENT[1], ACCENT[2], .22)
            self.glow = RoundedRectangle(radius=[dp(20)])
            self.tint = Color(1, 1, 1, 1)
            self.shape = RoundedRectangle(texture=accent_tex(), radius=[dp(16)])
        self.bind(pos=self.sync, size=self.sync,
                  state=self._press, disabled=self._press)
        self.sync()

    def _press(self, *_):
        if self.disabled:
            self.tint.rgba = (1, 1, 1, .45)
        elif self.state == "down":
            self.tint.rgba = (.82, .82, .82, 1)
        else:
            self.tint.rgba = (1, 1, 1, 1)

    def sync(self, *_):
        self.shape.pos = self.pos
        self.shape.size = self.size
        self.glow.pos = (self.x - dp(3), self.y - dp(5))
        self.glow.size = (self.width + dp(6), self.height + dp(6))


class DarkButton(Button):
    """الزر الثانوي: بطاقة داكنة بإطار رفيع. يقبل fill / border مخصصين."""

    def __init__(self, **kwargs):
        fill = kwargs.pop("fill", CARD2)
        border = kwargs.pop("border", BORDER)
        kwargs.setdefault("background_normal", "")
        kwargs.setdefault("background_down", "")
        kwargs.setdefault("background_color", (0, 0, 0, 0))
        kwargs.setdefault("color", TEXT)
        kwargs.setdefault("font_name", FONT_PATH)
        kwargs.setdefault("font_size", "15sp")
        if isinstance(kwargs.get("text"), str):
            kwargs["text"] = ar(kwargs["text"])
        super().__init__(**kwargs)
        self._base = fill
        with self.canvas.before:
            self._fillc = Color(*fill)
            self.shape = RoundedRectangle(radius=[dp(16)])
            Color(*border)
            self.outline = Line(rounded_rectangle=(0, 0, 1, 1, dp(16)), width=1)
        self.bind(pos=self.sync, size=self.sync, state=self._press)
        self.sync()

    def _press(self, *_):
        c = self._base
        if self.state == "down":
            self._fillc.rgba = (min(1, c[0] + .07), min(1, c[1] + .07),
                                min(1, c[2] + .09), min(1, c[3] + .1))
        else:
            self._fillc.rgba = c

    def set_active(self, on):
        """تبديل مظهر الزر (مفعّل بالوردي / عادي) — يُستخدم للتبويبات."""
        self._base = ACCENT if on else CARD2
        self._fillc.rgba = self._base
        self.color = WHITE if on else TEXT

    def sync(self, *_):
        self.shape.pos = self.pos
        self.shape.size = self.size
        self.outline.rounded_rectangle = _rr(
            self.x, self.y, self.width, self.height, dp(16))


# ───────────────────────── الأيقونات (مرسومة بالكود) ─────────────────────────
def _arc(cx, cy, rx, ry, a0, a1, n=20):
    pts = []
    for i in range(n + 1):
        a = math.radians(a0 + (a1 - a0) * i / n)
        pts += [cx + rx * math.cos(a), cy + ry * math.sin(a)]
    return pts


class Icon(Widget):
    kind = StringProperty("chat")
    color = ListProperty([1, 1, 1, 1])
    bg = ListProperty([0, 0, 0, 0])

    def __init__(self, kind="chat", color=TEXT, bg=CARD2, **kw):
        super().__init__(**kw)
        self.kind = kind
        self.color = list(color)
        self.bg = list(bg)
        self.bind(pos=self.redraw, size=self.redraw,
                  kind=self.redraw, color=self.redraw)
        self.redraw()

    def redraw(self, *_):
        self.canvas.clear()
        s = min(self.width, self.height) * .27
        if s <= 0:
            return
        cx, cy = self.center
        w = max(dp(1.5), s * .2)
        fn = getattr(self, "_i_" + self.kind, None)
        if fn is None:
            return
        with self.canvas:
            Color(*self.color)
            fn(cx, cy, s, w)

    def _i_back(self, cx, cy, s, w):
        Line(points=[cx - s * .3, cy + s * .6, cx + s * .3, cy, cx - s * .3, cy - s * .6],
             width=w, cap="round", joint="round")

    def _i_chev(self, cx, cy, s, w):
        Line(points=[cx + s * .3, cy + s * .6, cx - s * .3, cy, cx + s * .3, cy - s * .6],
             width=w, cap="round", joint="round")

    def _i_more(self, cx, cy, s, w):
        r = w * .95
        for dy in (-.62, 0, .62):
            Ellipse(pos=(cx - r, cy + dy * s - r), size=(2 * r, 2 * r))

    def _i_plus(self, cx, cy, s, w):
        Line(points=[cx - s * .8, cy, cx + s * .8, cy], width=w, cap="round")
        Line(points=[cx, cy - s * .8, cx, cy + s * .8], width=w, cap="round")

    def _i_send(self, cx, cy, s, w):
        tip = (cx - s * .85, cy)
        tr = (cx + s * .75, cy + s * .75)
        br = (cx + s * .75, cy - s * .75)
        mid = (cx + s * .3, cy)
        Triangle(points=[*tip, *tr, *mid])
        Triangle(points=[*tip, *mid, *br])

    def _i_chat(self, cx, cy, s, w):
        Line(rounded_rectangle=(cx - s, cy - s * .4, 2 * s, 1.3 * s, s * .42), width=w)
        Line(points=[cx - s * .35, cy - s * .4, cx - s * .65, cy - s * .95, cx + s * .1, cy - s * .4],
             width=w, joint="round", cap="round")

    def _i_user(self, cx, cy, s, w):
        cy = cy - s * .13
        Line(circle=(cx, cy + s * .62, s * .35), width=w)
        Line(points=_arc(cx, cy - s * .7, s * .85, s * .85, 0, 180), width=w, cap="round")

    def _i_users(self, cx, cy, s, w):
        cy = cy - s * .1
        Line(circle=(cx + s * .3, cy + s * .55, s * .3), width=w)
        Line(points=_arc(cx + s * .3, cy - s * .45, s * .75, s * .75, 0, 180), width=w, cap="round")
        Line(circle=(cx - s * .5, cy + s * .6, s * .24), width=w)
        Line(points=_arc(cx - s * .5, cy - s * .3, s * .55, s * .6, 90, 180), width=w, cap="round")

    def _i_sliders(self, cx, cy, s, w):
        for dy, kx in ((.62, -.35), (0, .4), (-.62, -.1)):
            Line(points=[cx - s, cy + dy * s, cx + s, cy + dy * s], width=w, cap="round")
            Ellipse(pos=(cx + kx * s - s * .24, cy + dy * s - s * .24), size=(s * .48, s * .48))

    def _i_shield(self, cx, cy, s, w):
        Line(points=[cx, cy + s, cx + s * .8, cy + s * .62, cx + s * .8, cy - s * .1,
                     cx, cy - s, cx - s * .8, cy - s * .1, cx - s * .8, cy + s * .62],
             width=w, close=True, joint="round")

    def _i_block(self, cx, cy, s, w):
        Line(circle=(cx, cy, s * .9), width=w)
        d = s * .64
        Line(points=[cx - d, cy + d, cx + d, cy - d], width=w, cap="round")

    def _i_bell(self, cx, cy, s, w):
        pts = _arc(cx, cy + s * .1, s * .7, s * .8, 0, 180)
        pts += [cx - s * .7, cy - s * .5, cx + s * .7, cy - s * .5]
        Line(points=pts, width=w, close=True, joint="round")
        Ellipse(pos=(cx - s * .2, cy - s * .95), size=(s * .4, s * .4))

    def _i_moon(self, cx, cy, s, w):
        Line(circle=(cx, cy, s * .9), width=w)
        Ellipse(pos=(cx - s * .9, cy - s * .9), size=(s * 1.8, s * 1.8),
                angle_start=0, angle_end=180)

    def _i_image(self, cx, cy, s, w):
        Line(rounded_rectangle=(cx - s, cy - s * .75, 2 * s, 1.5 * s, s * .25), width=w)
        Line(points=[cx - s * .8, cy - s * .5, cx - s * .2, cy + s * .1,
                     cx + s * .2, cy - s * .3, cx + s * .5, cy, cx + s * .8, cy - s * .3],
             width=w, joint="round", cap="round")
        Ellipse(pos=(cx + s * .35, cy + s * .22), size=(s * .3, s * .3))

    def _i_info(self, cx, cy, s, w):
        Line(circle=(cx, cy, s * .9), width=w)
        Line(points=[cx, cy - s * .1, cx, cy - s * .45], width=w, cap="round")
        Ellipse(pos=(cx - w * .8, cy + s * .25), size=(w * 1.6, w * 1.6))

    def _i_eye(self, cx, cy, s, w):
        Line(ellipse=(cx - s, cy - s * .55, 2 * s, 1.1 * s), width=w)
        Ellipse(pos=(cx - s * .27, cy - s * .27), size=(s * .54, s * .54))

    def _i_flag(self, cx, cy, s, w):
        Line(points=[cx - s * .6, cy - s, cx - s * .6, cy + s], width=w, cap="round")
        Line(points=[cx - s * .6, cy + s, cx + s * .8, cy + s * .55, cx - s * .6, cy + s * .1],
             width=w, joint="round")


    def _i_mic(self, cx, cy, s, w):
        Line(rounded_rectangle=(cx - s * .36, cy - s * .15, s * .72, s * 1.25, s * .36), width=w)
        Line(points=_arc(cx, cy + s * .05, s * .78, s * .85, 200, 340), width=w, cap="round")
        Line(points=[cx, cy - s * .8, cx, cy - s * 1.05], width=w, cap="round")
        Line(points=[cx - s * .4, cy - s * 1.05, cx + s * .4, cy - s * 1.05], width=w, cap="round")

    def _i_camera(self, cx, cy, s, w):
        Line(rounded_rectangle=(cx - s, cy - s * .62, 2 * s, 1.35 * s, s * .28), width=w)
        Line(circle=(cx, cy + s * .05, s * .4), width=w)
        Line(points=[cx - s * .42, cy + s * .73, cx - s * .25, cy + s * 1.0,
                     cx + s * .25, cy + s * 1.0, cx + s * .42, cy + s * .73],
             width=w, joint="round", cap="round")

    def _i_play(self, cx, cy, s, w):
        Triangle(points=[cx - s * .45, cy + s * .85, cx - s * .45, cy - s * .85,
                         cx + s * .8, cy])

    def _i_pause(self, cx, cy, s, w):
        Rectangle(pos=(cx - s * .65, cy - s * .75), size=(s * .45, s * 1.5))
        Rectangle(pos=(cx + s * .2, cy - s * .75), size=(s * .45, s * 1.5))



    def _i_star(self, cx, cy, s, w):
        pts = []
        for i in range(10):
            ang = math.radians(90 + i * 36)
            rad = s if i % 2 == 0 else s * .42
            pts.append((cx + rad * math.cos(ang), cy + rad * math.sin(ang)))
        for i in range(10):
            a, b = pts[i], pts[(i + 1) % 10]
            Triangle(points=[cx, cy, a[0], a[1], b[0], b[1]])


class IconChip(Widget):
    """دائرة بأيقونة بداخلها (غير تفاعلية)."""

    def __init__(self, kind="info", color=TEXT, bg=None, grad=False, **kw):
        kw.setdefault("size_hint", (None, None))
        kw.setdefault("size", (dp(44), dp(44)))
        super().__init__(**kw)
        self.grad = grad
        with self.canvas.before:
            if grad:
                Color(ACCENT[0], ACCENT[1], ACCENT[2], .25)
                self._glow = Ellipse()
                Color(1, 1, 1, 1)
                self._bg = Ellipse(texture=accent_tex())
            else:
                Color(*(bg if bg else (0, 0, 0, 0)))
                self._bg = Ellipse()
        self.icon = Icon(kind, color, bg=(bg if bg else CARD2))
        self.add_widget(self.icon)
        self.bind(pos=self._sync, size=self._sync)
        self._sync()

    def _sync(self, *_):
        self._bg.pos = self.pos
        self._bg.size = self.size
        if self.grad:
            self._glow.pos = (self.x - dp(3), self.y - dp(4))
            self._glow.size = (self.width + dp(6), self.height + dp(6))
        self.icon.pos = self.pos
        self.icon.size = self.size


class IconButton(ButtonBehavior, IconChip):
    def __init__(self, kind="info", color=TEXT, **kw):
        super().__init__(kind=kind, color=color, **kw)


def anchor(widget, width=None, height=None):
    """يضع عنصراً بحجم ثابت في وسط خانة (لمحاذاته عمودياً داخل الصفوف)."""
    box = AnchorLayout(size_hint=(None, 1), width=width or widget.width)
    box.add_widget(widget)
    return box


# ───────────────────────── الشعار: وردة مرسومة ─────────────────────────
class RoseLogo(Widget):
    def __init__(self, **kw):
        kw.setdefault("size_hint", (None, None))
        kw.setdefault("size", (dp(96), dp(96)))
        super().__init__(**kw)
        self.bind(pos=self.redraw, size=self.redraw)
        self.redraw()

    def redraw(self, *_):
        self.canvas.clear()
        cx, cy = self.center
        r = min(self.size) / 2.0
        with self.canvas:
            for i in range(5):
                Color(ACCENT[0], ACCENT[1], ACCENT[2], .035)
                rr = r * (1 - i * .09)
                Ellipse(pos=(cx - rr, cy - rr), size=(2 * rr, 2 * rr))
            layers = [
                (6, 0, hexa("#8E2A66", .92), .27, .78, .06),
                (6, 30, hexa("#B8337E", .92), .24, .66, .05),
                (5, 12, hexa("#F2517F", .95), .20, .52, .04),
                (5, 48, hexa("#FF7FA3", .95), .15, .38, .03),
            ]
            for count, offset, col, wk, hk, gap in layers:
                for k in range(count):
                    PushMatrix()
                    Rotate(angle=offset + k * (360.0 / count), origin=(cx, cy))
                    Color(*col)
                    Ellipse(pos=(cx - r * wk, cy + r * gap),
                            size=(r * wk * 2, r * hk))
                    PopMatrix()
            Color(hexa("#FFD3E0")[0], hexa("#FFD3E0")[1], hexa("#FFD3E0")[2], 1)
            c = r * .13
            Ellipse(pos=(cx - c, cy - c), size=(2 * c, 2 * c))


# ───────────────────────── الصورة الشخصية الدائرية ─────────────────────────
def make_image(cls, source):
    try:
        return cls(source=source, size_hint=(None, None), fit_mode="cover")
    except Exception:
        return cls(source=source, size_hint=(None, None),
                   allow_stretch=True, keep_ratio=False)


class CircularAvatar(FloatLayout):
    """صورة دائرية بإطار متدرج. تدعم الصور المحلية والروابط."""

    def __init__(self, source="", size=110, ring=True, initial="", **kwargs):
        if isinstance(size, (int, float)):
            size = (dp(size), dp(size))
        kwargs.setdefault("size_hint", (None, None))
        super().__init__(size=size, **kwargs)
        self.initial = str(initial or "?")[:1].upper()
        self.ring = ring
        self.inset = dp(3.5) if ring else dp(1)
        src = str(source or "")
        is_url = src.startswith("http")
        self.source = src if (src and (is_url or os.path.exists(src))) else ""

        self.image = None
        self.placeholder = None
        self.initial_label = None

        if self.source:
            self.image = make_image(AsyncImage if is_url else Image, self.source)
            self.add_widget(self.image)
        else:
            col = AVATAR_COLORS[ord(self.initial[0]) % len(AVATAR_COLORS)]
            self.placeholder = Widget(size_hint=(None, None))
            with self.placeholder.canvas:
                Color(*col)
                self.placeholder_shape = Ellipse()
            self.add_widget(self.placeholder)
            self.initial_label = Label(
                text=self.initial,
                font_name=FONT_PATH,
                font_size="30sp",
                color=WHITE,
                size_hint=(None, None),
                halign="center",
                valign="middle",
            )
            self.add_widget(self.initial_label)

        with self.canvas.before:
            if ring:
                Color(1, 1, 1, 1)
                self.ring_shape = Ellipse(
                    texture=gradient("ring", [ACCENT, GOLD], vertical=True))
            StencilPush()
            self.clip_shape = Ellipse()
            StencilUse()

        with self.canvas.after:
            StencilUnUse()
            self.clip_shape2 = Ellipse()
            StencilPop()

        self.bind(pos=self.sync, size=self.sync)
        self.sync()

    def sync(self, *_):
        inner_pos = (self.x + self.inset, self.y + self.inset)
        inner_size = (
            max(dp(1), self.width - 2 * self.inset),
            max(dp(1), self.height - 2 * self.inset),
        )
        self.clip_shape.pos = inner_pos
        self.clip_shape.size = inner_size
        self.clip_shape2.pos = inner_pos
        self.clip_shape2.size = inner_size
        if self.image is not None:
            self.image.pos = inner_pos
            self.image.size = inner_size
        if self.placeholder is not None:
            self.placeholder.pos = inner_pos
            self.placeholder.size = inner_size
            self.placeholder_shape.pos = inner_pos
            self.placeholder_shape.size = inner_size
        if self.initial_label is not None:
            self.initial_label.pos = inner_pos
            self.initial_label.size = inner_size
            self.initial_label.text_size = inner_size
            self.initial_label.font_size = max(dp(12), inner_size[0] * .42)
        if hasattr(self, "ring_shape"):
            self.ring_shape.pos = self.pos
            self.ring_shape.size = self.size


# ───────────────────────── حقل الإدخال ─────────────────────────
class FieldBox(BoxLayout):
    """حقل نص بحواف دائرية وإطار يضيء عند التركيز. النص الفعلي في self.input"""

    def __init__(self, hint="", password=False, height=54, draw=True, **kw):
        kw.setdefault("size_hint_y", None)
        super().__init__(height=dp(height), padding=[dp(4), 0], **kw)
        self.input = TextInput(
            hint_text=ar(hint) if hint else "",
            password=password,
            multiline=False,
            font_name=FONT_PATH,
            font_size="15sp",
            background_normal="",
            background_active="",
            background_color=(0, 0, 0, 0),
            foreground_color=TEXT,
            hint_text_color=MUTED,
            cursor_color=ACCENT,
            selection_color=(ACCENT[0], ACCENT[1], ACCENT[2], .35),
            halign="right",
            padding=[dp(14), dp(14), dp(14), dp(10)],
        )
        self.add_widget(self.input)
        self._draw = draw
        self.input.bind(size=self._pad, focus=self._focus)
        if draw:
            with self.canvas.before:
                Color(*FIELD)
                self._bg = RoundedRectangle(radius=[dp(16)])
                self._bc = Color(*BORDER)
                self._ln = Line(rounded_rectangle=(0, 0, 1, 1, dp(16)), width=1)
            self.bind(pos=self._sync, size=self._sync)
            self._sync()

    def _pad(self, *_):
        ti = self.input
        ph = max(dp(6), (ti.height - ti.line_height) / 2.0)
        ti.padding = [dp(14), ph, dp(14), ph]

    def _focus(self, _w, focused):
        if not self._draw:
            return
        self._bc.rgba = ACCENT if focused else BORDER
        self._ln.width = 1.6 if focused else 1

    def _sync(self, *_):
        self._bg.pos = self.pos
        self._bg.size = self.size
        self._ln.rounded_rectangle = _rr(self.x, self.y, self.width, self.height, dp(16))


# ───────────────────────── النوافذ المنبثقة ─────────────────────────
class StyledPopup(Popup):
    def __init__(self, **kw):
        kw.setdefault("background", "")
        kw["background_color"] = (0, 0, 0, 0)
        kw.setdefault("separator_color", ACCENT)
        kw.setdefault("separator_height", dp(2))
        kw.setdefault("title_font", FONT_PATH)
        kw.setdefault("title_color", TEXT)
        kw.setdefault("title_size", "17sp")
        kw.setdefault("title_align", "center")
        kw.setdefault("overlay_color", (0, 0, 0, .74))
        super().__init__(**kw)
        with self.canvas.before:
            Color(*CARD)
            self._r = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(24)])
            Color(*BORDER)
            self._l = Line(rounded_rectangle=_rr(self.x, self.y, self.width, self.height, dp(24)),
                           width=1)
        self.bind(pos=self._sync_pop, size=self._sync_pop)

    def _sync_pop(self, *_):
        self._r.pos = self.pos
        self._r.size = self.size
        self._l.rounded_rectangle = _rr(self.x, self.y, self.width, self.height, dp(24))


# ───────────────────────── صف الإعدادات ─────────────────────────
class ActionRow(ButtonBehavior, Card):
    def __init__(self, title, subtitle="", icon="info", **kwargs):
        kwargs.setdefault("size_hint_y", None)
        kwargs.setdefault("height", dp(72))
        super().__init__(orientation="horizontal", spacing=dp(12),
                         padding=[dp(14), dp(10)], fill=CARD, **kwargs)
        self.bind(state=lambda *_: self.set_pressed(self.state == "down"))
        chev = Icon("chev", MUTED, size_hint=(None, None), size=(dp(26), dp(26)))
        self.add_widget(anchor(chev, dp(26)))
        col = BoxLayout(orientation="vertical", padding=[0, dp(6)])
        t = Label(text=ar(title), font_name=FONT_PATH, font_size=dp(16), color=TEXT,
                  halign="right", valign="middle")
        t.bind(size=lambda w, v: setattr(w, "text_size", v))
        col.add_widget(t)
        if subtitle:
            sub = Label(text=ar(subtitle), font_name=FONT_PATH, font_size=dp(12),
                        color=MUTED, halign="right", valign="middle")
            sub.bind(size=lambda w, v: setattr(w, "text_size", v))
            col.add_widget(sub)
        self.add_widget(col)
        chip = IconChip(icon, color=ACCENT, bg=(ACCENT[0], ACCENT[1], ACCENT[2], .16))
        self.add_widget(anchor(chip, dp(44)))


class NavItem(ButtonBehavior, BoxLayout):
    """عنصر شريط التنقل السفلي: أيقونة + نص، والنشط يظهر بكبسولة وردية."""

    def __init__(self, title, kind, active=False, **kw):
        super().__init__(orientation="vertical", padding=[0, dp(7), 0, dp(4)],
                         spacing=dp(1), **kw)
        col = ACCENT if active else MUTED
        if active:
            with self.canvas.before:
                Color(ACCENT[0], ACCENT[1], ACCENT[2], .16)
                self._pill = RoundedRectangle(radius=[dp(18)])
            self.bind(pos=self._sync_pill, size=self._sync_pill)
            self._sync_pill()
        holder = AnchorLayout(size_hint_y=None, height=dp(28))
        holder.add_widget(Icon(kind, col, size_hint=(None, None), size=(dp(36), dp(36))))
        self.add_widget(holder)
        self.add_widget(Label(
            text=ar(title), font_name=FONT_PATH, font_size="11sp",
            color=col, size_hint_y=None, height=dp(16)))

    def _sync_pill(self, *_):
        self._pill.pos = (self.x + dp(2), self.y + dp(2))
        self._pill.size = (max(1, self.width - dp(4)), max(1, self.height - dp(4)))


def load_local():
    data = dict(DEFAULT_DATA)
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data.update(json.load(f))
    except Exception:
        pass
    return data


def save_local(data):
    try:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as exc:
        print("Local save error:", exc)


def headers(token=None):
    h = {"apikey": SUPABASE_KEY, "Content-Type": "application/json"}
    if token:
        h["Authorization"] = "Bearer " + token
    return h


# ═══════════════════════════════════════════════════════════════
#  الوسائط: رفع الصور، الكاميرا، المعرض، التسجيل الصوتي والتشغيل
# ═══════════════════════════════════════════════════════════════
IS_ANDROID = platform == "android"
MEDIA_IMG = "[[img]]"
MEDIA_VOICE = "[[voice]]"
AVATAR_BUCKET = "avatars"
MEDIA_BUCKET = "chat-media"
MAX_VOICE_SECONDS = 180


def parse_media(content):
    """يرجع (النوع, القيمة, المدة). النوع: text | image | voice."""
    c = str(content or "")
    if c.startswith(MEDIA_IMG):
        return "image", c[len(MEDIA_IMG):].strip(), 0
    if c.startswith(MEDIA_VOICE):
        url, _, secs = c[len(MEDIA_VOICE):].strip().partition("|")
        try:
            dur = int(float(secs))
        except Exception:
            dur = 0
        return "voice", url, dur
    return "text", c, 0


def preview_text(content):
    kind, _, _ = parse_media(content)
    if kind == "image":
        return "صورة"
    if kind == "voice":
        return "رسالة صوتية"
    return str(content)[:55] or "رسالة"


def local_hhmm(created):
    """يحوّل وقت السيرفر (UTC) إلى توقيت الجهاز."""
    created = str(created or "")
    try:
        dt = datetime.fromisoformat(created.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone().strftime("%H:%M")
    except Exception:
        return created.split("T", 1)[1][:5] if "T" in created else ""


def cache_dir():
    base = App.get_running_app().user_data_dir
    path = os.path.join(base, "cache")
    os.makedirs(path, exist_ok=True)
    return path


def run_bg(work, done=None):
    """ينفذ work في خيط خلفي ثم يستدعي done(result, error) على الواجهة."""
    def runner():
        try:
            res, err = work(), None
        except Exception as exc:
            res, err = None, exc
        if done:
            Clock.schedule_once(lambda dt: done(res, err), 0)
    threading.Thread(target=runner, daemon=True).start()


def storage_upload(token, bucket, path, data, content_type):
    r = requests.post(
        SUPABASE_URL + "/storage/v1/object/" + bucket + "/" + path,
        headers={
            "apikey": SUPABASE_KEY,
            "Authorization": "Bearer " + token,
            "Content-Type": content_type,
            "x-upsert": "true",
        },
        data=data, timeout=90,
    )
    if r.status_code not in (200, 201):
        raise RuntimeError(r.text)
    return SUPABASE_URL + "/storage/v1/object/public/" + bucket + "/" + path


def prepare_image_bytes(path, max_side=1280, quality=85):
    """يصغّر الصورة ويضغطها قبل الرفع. يرجع (bytes, content_type, ext)."""
    try:
        from PIL import Image as PILImage, ImageOps
        im = ImageOps.exif_transpose(PILImage.open(path)).convert("RGB")
        im.thumbnail((max_side, max_side))
        buf = io.BytesIO()
        im.save(buf, "JPEG", quality=quality)
        return buf.getvalue(), "image/jpeg", "jpg"
    except Exception:
        with open(path, "rb") as f:
            data = f.read()
        ext = os.path.splitext(path)[1].lower().lstrip(".")
        if ext == "png":
            return data, "image/png", "png"
        return data, "image/jpeg", "jpg"


def ask_permissions(perms, callback=None):
    """يطلب صلاحيات أندرويد ثم يستدعي callback(granted) على الواجهة."""
    if not IS_ANDROID:
        if callback:
            callback(True)
        return
    try:
        from android.permissions import request_permissions

        def result(_perms, grants):
            if callback:
                ok = all(bool(g) for g in grants)
                Clock.schedule_once(lambda dt: callback(ok), 0)

        request_permissions(perms, result)
    except Exception as exc:
        print("Permission error:", exc)
        if callback:
            callback(False)


def choose_image_file(on_path):
    """منتقي ملفات احتياطي (للحاسوب أو إذا فشل منتقي النظام)."""
    chooser = FileChooserListView(
        path="/storage/emulated/0" if IS_ANDROID else os.path.expanduser("~"),
        filters=["*.png", "*.jpg", "*.jpeg", "*.webp"],
    )
    box = BoxLayout(orientation="vertical", padding=dp(8), spacing=dp(8))
    buttons = BoxLayout(size_hint_y=None, height=dp(50), spacing=dp(8))
    box.add_widget(chooser)
    box.add_widget(buttons)
    cancel = DarkButton(text="إلغاء")
    choose = GoldButton(text="اختيار")
    buttons.add_widget(cancel)
    buttons.add_widget(choose)
    pop = StyledPopup(title=ar("اختيار صورة"), content=box, size_hint=(.95, .88))
    cancel.bind(on_release=pop.dismiss)

    def picked(*_):
        if chooser.selection:
            pop.dismiss()
            on_path(chooser.selection[0])

    choose.bind(on_release=picked)
    pop.open()


class NativeMedia:
    """المعرض والكاميرا عبر نظام أندرويد مباشرة (بدون متصفح ملفات)."""
    _chooser = None

    @staticmethod
    def _uri_to_path(uri):
        try:
            from androidstorage4kivy import SharedStorage
            path = SharedStorage().copy_from_shared(uri)
            if path:
                return path
        except Exception as exc:
            print("SharedStorage copy failed:", exc)
        # بديل: نسخ مباشر عبر Java
        from jnius import autoclass
        PythonActivity = autoclass("org.kivy.android.PythonActivity")
        FileOutputStream = autoclass("java.io.FileOutputStream")
        FileUtils = autoclass("android.os.FileUtils")
        resolver = PythonActivity.mActivity.getContentResolver()
        stream = resolver.openInputStream(uri)
        out_path = os.path.join(cache_dir(), "img_%d.jpg" % int(time.time() * 1000))
        fos = FileOutputStream(out_path)
        FileUtils.copy(stream, fos)
        fos.close()
        stream.close()
        return out_path

    @classmethod
    def pick_image(cls, on_path, on_fail):
        def fail(msg):
            Clock.schedule_once(lambda dt: on_fail(str(msg)), 0)

        if not IS_ANDROID:
            fail("desktop")
            return
        try:
            from androidstorage4kivy import Chooser

            def got(uris):
                if not uris:
                    return
                try:
                    path = cls._uri_to_path(uris[0])
                    Clock.schedule_once(lambda dt: on_path(path), 0)
                except Exception as exc:
                    fail(exc)

            cls._chooser = Chooser(got)
            cls._chooser.choose_content("image/*")
        except Exception as exc:
            fail(exc)

    @classmethod
    def take_photo(cls, on_path, on_fail):
        def fail(msg):
            Clock.schedule_once(lambda dt: on_fail(str(msg)), 0)

        if not IS_ANDROID:
            fail("desktop")
            return
        try:
            from jnius import autoclass, cast
            from android import activity
            PythonActivity = autoclass("org.kivy.android.PythonActivity")
            Intent = autoclass("android.content.Intent")
            Media = autoclass("android.provider.MediaStore$Images$Media")
            ContentValues = autoclass("android.content.ContentValues")
            act = PythonActivity.mActivity
            values = ContentValues()
            values.put("_display_name", "alward_%d.jpg" % int(time.time()))
            values.put("mime_type", "image/jpeg")
            values.put("relative_path", "Pictures/ALWard")
            uri = act.getContentResolver().insert(Media.EXTERNAL_CONTENT_URI, values)
            req = 7311

            def on_result(request, result, intent):
                if request != req:
                    return
                activity.unbind(on_activity_result=on_result)
                if result == -1:
                    try:
                        path = cls._uri_to_path(uri)
                        Clock.schedule_once(lambda dt: on_path(path), 0)
                    except Exception as exc:
                        fail(exc)
                else:
                    try:
                        act.getContentResolver().delete(uri, None, None)
                    except Exception:
                        pass

            activity.bind(on_activity_result=on_result)
            intent = Intent("android.media.action.IMAGE_CAPTURE")
            intent.putExtra("output", cast("android.os.Parcelable", uri))
            act.startActivityForResult(intent, req)
        except Exception as exc:
            fail(exc)


class VoiceRecorder:
    """تسجيل صوتي بصيغة m4a (AAC) عبر MediaRecorder في أندرويد."""

    def __init__(self):
        self.rec = None
        self.path = None
        self.t0 = 0

    def start(self):
        if not IS_ANDROID:
            raise RuntimeError("التسجيل الصوتي يعمل على الأندرويد فقط.")
        from jnius import autoclass
        MediaRecorder = autoclass("android.media.MediaRecorder")
        AudioSource = autoclass("android.media.MediaRecorder$AudioSource")
        OutputFormat = autoclass("android.media.MediaRecorder$OutputFormat")
        AudioEncoder = autoclass("android.media.MediaRecorder$AudioEncoder")
        self.path = os.path.join(cache_dir(), "voice_%d.m4a" % int(time.time() * 1000))
        rec = MediaRecorder()
        rec.setAudioSource(AudioSource.MIC)
        rec.setOutputFormat(OutputFormat.MPEG_4)
        rec.setAudioEncoder(AudioEncoder.AAC)
        rec.setAudioEncodingBitRate(64000)
        rec.setAudioSamplingRate(44100)
        rec.setOutputFile(self.path)
        rec.prepare()
        rec.start()
        self.rec = rec
        self.t0 = time.time()

    def stop(self):
        """يوقف التسجيل ويرجع (المسار, عدد الثواني)."""
        rec, self.rec = self.rec, None
        secs = int(round(time.time() - self.t0))
        if rec is not None:
            try:
                rec.stop()
            except Exception:
                secs = 0  # تسجيل قصير جداً
            finally:
                try:
                    rec.release()
                except Exception:
                    pass
        return self.path, secs

    def discard(self):
        path, _ = self.stop()
        try:
            if path and os.path.exists(path):
                os.remove(path)
        except Exception:
            pass


class VoicePlayer:
    """مشغّل الرسائل الصوتية: ينزّل الملف مرة واحدة ثم يشغّله عبر MediaPlayer."""
    player = None
    current_url = None
    ui = None
    event = None

    @classmethod
    def stop(cls):
        if cls.event is not None:
            cls.event.cancel()
            cls.event = None
        if cls.player is not None:
            try:
                cls.player.stop()
            except Exception:
                pass
            try:
                cls.player.release()
            except Exception:
                pass
            cls.player = None
        ui, cls.ui = cls.ui, None
        cls.current_url = None
        if ui is not None:
            ui.set_state(False)
            ui.set_progress(0)

    @classmethod
    def toggle(cls, url, ui):
        if cls.current_url == url:
            cls.stop()
            return
        cls.stop()
        cls.current_url = url
        cls.ui = ui
        ui.set_state(True)

        def work():
            local = os.path.join(
                cache_dir(), hashlib.md5(url.encode()).hexdigest() + ".m4a")
            if not os.path.exists(local):
                r = requests.get(url, timeout=60)
                if r.status_code != 200:
                    raise RuntimeError("تعذر تحميل الصوت")
                with open(local, "wb") as f:
                    f.write(r.content)
            return local

        def done(path, err):
            if cls.current_url != url:
                return
            if err or not path:
                cls.stop()
                App.get_running_app().error("تعذر تشغيل الرسالة الصوتية.\n" + str(err or ""))
                return
            cls._start(path)

        run_bg(work, done)

    @classmethod
    def _start(cls, path):
        if not IS_ANDROID:
            cls.stop()
            return
        try:
            from jnius import autoclass
            MediaPlayer = autoclass("android.media.MediaPlayer")
            mp = MediaPlayer()
            mp.setDataSource(path)
            mp.prepare()
            mp.start()
            cls.player = mp
            cls.event = Clock.schedule_interval(cls._tick, .25)
        except Exception as exc:
            cls.stop()
            App.get_running_app().error("تعذر تشغيل الصوت.\n" + str(exc))

    @classmethod
    def _tick(cls, _dt):
        mp = cls.player
        if mp is None:
            return False
        try:
            playing = mp.isPlaying()
            dur = max(1, mp.getDuration())
            pos = mp.getCurrentPosition()
        except Exception:
            cls.stop()
            return False
        if cls.ui is not None:
            cls.ui.set_progress(min(1.0, pos / float(dur)))
        if not playing:
            cls.stop()
            return False
        return True


class VoiceBar(Widget):
    """شريط تقدّم الرسالة الصوتية."""
    progress = NumericProperty(0)

    def __init__(self, track=(1, 1, 1, .3), fill=WHITE, **kw):
        super().__init__(**kw)
        with self.canvas:
            Color(*track)
            self._t = RoundedRectangle(radius=[dp(3)])
            Color(*fill)
            self._f = RoundedRectangle(radius=[dp(3)])
        self.bind(pos=self._sync, size=self._sync, progress=self._sync)
        self._sync()

    def _sync(self, *_):
        h = dp(5)
        y = self.center_y - h / 2
        self._t.pos = (self.x, y)
        self._t.size = (max(1, self.width), h)
        self._f.pos = (self.x, y)
        self._f.size = (max(.1, self.width * self.progress), h)


class VoiceUI:
    def __init__(self, btn, bar):
        self.btn = btn
        self.bar = bar

    def set_state(self, playing):
        self.btn.icon.kind = "pause" if playing else "play"

    def set_progress(self, frac):
        self.bar.progress = frac


class TapImage(ButtonBehavior, AsyncImage):
    pass


def make_tap_image(url):
    try:
        return TapImage(source=url, fit_mode="cover", size_hint=(1, None))
    except Exception:
        return TapImage(source=url, allow_stretch=True, keep_ratio=False,
                        size_hint=(1, None))


def show_image_viewer(url):
    img = AsyncImage(source=url)
    box = BoxLayout(padding=dp(6))
    box.add_widget(img)
    pop = StyledPopup(title=ar("صورة"), content=box, size_hint=(.96, .82))
    img.bind(on_touch_down=lambda w, t: pop.dismiss() if w.collide_point(*t.pos) else False)
    pop.open()




def fetch_profiles(app):
    """قائمة المستخدمين (عدا أنا). يعمل حتى لو عمود status غير موجود بعد."""
    base = SUPABASE_URL + "/rest/v1/profiles?select=%s&order=username.asc"
    r = requests.get(base % "id,username,last_seen,avatar_url,status",
                     headers=headers(app.token), timeout=20)
    if r.status_code == 400:
        r = requests.get(base % "id,username,last_seen,avatar_url",
                         headers=headers(app.token), timeout=20)
    if r.status_code != 200:
        raise RuntimeError(r.text)
    return [u for u in r.json() if str(u.get("id")) != str(app.user_id)]


def fetch_chat_data(app):
    """يجلب كل بيانات الشاشة الرئيسية بعدد قليل من الطلبات (يعمل بخيط خلفي)."""
    h = headers(app.token)
    me = str(app.user_id)
    users = fetch_profiles(app)

    by_conv = {}
    mem = requests.get(
        SUPABASE_URL + "/rest/v1/conversation_members?select=conversation_id,user_id",
        headers=h, timeout=20)
    if mem.status_code == 200:
        for row in mem.json():
            by_conv.setdefault(str(row.get("conversation_id")), set()).add(str(row.get("user_id")))
    conv_of = {}
    for cid, members in by_conv.items():
        if me in members:
            for u in members:
                if u != me:
                    conv_of.setdefault(u, cid)

    last, unread = {}, {}
    cids = sorted(set(conv_of.values()))
    if cids:
        base = (SUPABASE_URL + "/rest/v1/messages?select=%s&conversation_id=in.("
                + ",".join(cids) + ")&order=created_at.desc&limit=300")
        rr = requests.get(base % "conversation_id,sender_id,content,created_at,read_at",
                          headers=h, timeout=20)
        if rr.status_code == 400:  # عمود read_at غير موجود بعد
            rr = requests.get(base % "conversation_id,sender_id,content,created_at",
                              headers=h, timeout=20)
        rows = rr.json() if rr.status_code == 200 else []
        for m in rows:
            cid = str(m.get("conversation_id"))
            if cid not in last:
                last[cid] = m
            if str(m.get("sender_id")) != me and "read_at" in m and not m.get("read_at"):
                unread[cid] = unread.get(cid, 0) + 1

        missing = [c for c in cids if c not in last]
        if missing:
            def one(c):
                x = requests.get(
                    SUPABASE_URL + "/rest/v1/messages?select=conversation_id,sender_id,content,created_at"
                    "&conversation_id=eq." + c + "&order=created_at.desc&limit=1",
                    headers=h, timeout=15)
                if x.status_code == 200 and x.json():
                    return x.json()[0]
                return None

            with ThreadPoolExecutor(max_workers=6) as pool:
                for c, m in zip(missing, pool.map(one, missing)):
                    if m:
                        last[c] = m

    items = []
    for u in users:
        cid = conv_of.get(str(u.get("id")))
        items.append({
            "user": u,
            "last": last.get(cid) if cid else None,
            "unread": unread.get(cid, 0) if cid else 0,
            "online": app.is_online(u.get("last_seen")),
        })
    items.sort(key=lambda it: str(it["user"].get("username") or "").lower())
    items.sort(key=lambda it: str(it["last"].get("created_at")) if it["last"] else "", reverse=True)
    sig = tuple(
        (str(i["user"].get("id")),
         str(i["last"].get("created_at")) if i["last"] else "",
         i["unread"], i["online"],
         i["user"].get("avatar_url") or "", i["user"].get("status") or "")
        for i in items)
    return {"items": items, "sig": sig}


class BaseScreen(Screen):
    def app(self):
        return App.get_running_app()

    def go(self, name):
        self.manager.current = name



class LoginScreen(BaseScreen):
    def login(self):
        username = self.ids.username.text.strip()
        password = self.ids.password.text
        if not username or not password:
            self.app().error("اكتب اسم المستخدم وكلمة المرور.")
            return
        self.ids.login_btn.disabled = True
        try:
            r = requests.post(
                SUPABASE_URL + "/auth/v1/token?grant_type=password",
                headers=headers(),
                json={"email": username.lower() + "@alward.app", "password": password},
                timeout=20,
            )
            data = r.json()
            if r.status_code != 200:
                self.app().error(
                    data.get("msg") or data.get("message") or
                    data.get("error_description") or "فشل تسجيل الدخول."
                )
                return
            app = self.app()
            app.token = data["access_token"]
            app.user_id = data["user"]["id"]
            app.username = username
            app.local["username"] = username
            app.local["refresh_token"] = data.get("refresh_token", "")
            save_local(app.local)
            app.ensure_profile()
            app.load_my_avatar()
            app.start_presence()
            app.start_token_refresh()
            self.manager.current = "home"
        except Exception as exc:
            self.app().error("تعذر الاتصال بالخادم.\n" + str(exc))
        finally:
            self.ids.login_btn.disabled = False

    def create_account(self):
        self.go("signup")


class SignupScreen(BaseScreen):
    def create(self):
        username = self.ids.username.text.strip()
        password = self.ids.password.text
        confirm = self.ids.confirm.text
        if len(username) < 3 or " " in username:
            self.app().error("اسم المستخدم يجب أن يكون 3 أحرف على الأقل وبدون مسافات.")
            return
        if len(password) < 6:
            self.app().error("كلمة المرور يجب أن تكون 6 أحرف على الأقل.")
            return
        if password != confirm:
            self.app().error("كلمتا المرور غير متطابقتين.")
            return
        try:
            r = requests.post(
                SUPABASE_URL + "/auth/v1/signup",
                headers=headers(),
                json={
                    "email": username.lower() + "@alward.app",
                    "password": password,
                    "data": {"username": username},
                },
                timeout=20,
            )
            data = r.json()
            if r.status_code not in (200, 201):
                self.app().error(
                    data.get("msg") or data.get("message") or
                    data.get("error_description") or "تعذر إنشاء الحساب."
                )
                return
            self.app().notice("تم إنشاء الحساب. سجل الدخول الآن.")
            self.manager.current = "login"
            self.manager.get_screen("login").ids.username.text = username
        except Exception as exc:
            self.app().error("تعذر الاتصال بالخادم.\n" + str(exc))


class HomeScreen(BaseScreen):
    _chat_items = []
    _data = None
    _sig = None
    _loading = False
    _query = ""
    _tab = "all"
    _poll = None

    def on_pre_enter(self, *_):
        self.load_chats()

    def on_enter(self, *_):
        if self._poll:
            self._poll.cancel()
        self._poll = Clock.schedule_interval(lambda dt: self.load_chats(), 8)

    def on_leave(self, *_):
        if self._poll:
            self._poll.cancel()
            self._poll = None

    # ── البحث والتبويبات ──
    def filter_chats(self, text):
        self._query = (text or "").strip().lower()
        self.apply_filters()

    def set_tab(self, tab):
        self._tab = tab
        for key in ("all", "unread", "fav"):
            getattr(self.ids, "tab_" + key).set_active(key == tab)
        self.apply_filters()

    def apply_filters(self):
        q = self._query
        for item in self._chat_items:
            ok = (not q) or q in item["name"].lower() or q in item["preview"].lower()
            if self._tab == "unread":
                ok = ok and item["unread"] > 0
            elif self._tab == "fav":
                ok = ok and item["fav"]
            item["widget"].height = dp(82) if ok else 0
            item["widget"].opacity = 1 if ok else 0

    # ── التحميل (بخيط خلفي) ──
    def load_chats(self):
        app = self.app()
        if not app.token:
            self.go("login")
            return
        if self._loading:
            return
        self._loading = True
        if self._data is None:
            box = self.ids.chat_list
            box.clear_widgets()
            box.add_widget(app.label("جاري التحميل...", 16, MUTED,
                                     size_hint_y=None, height=dp(100)))
        run_bg(lambda: fetch_chat_data(app), self._on_chats)

    def _on_chats(self, data, err):
        self._loading = False
        app = self.app()
        if err:
            if self._data is None:
                self.ids.chat_list.clear_widgets()
                app.error("تعذر الاتصال بالخادم.\n" + str(err))
            return
        first = self._data is None
        self._data = data
        if data["sig"] == self._sig and not first:
            return
        self._sig = data["sig"]
        self.render_chats()

    def render_chats(self):
        app = self.app()
        box = self.ids.chat_list
        box.clear_widgets()
        self._chat_items = []
        items = (self._data or {}).get("items", [])
        if not items:
            box.add_widget(app.label("لا يوجد مستخدمون آخرون حالياً.", 17, MUTED,
                                     size_hint_y=None, height=dp(100)))
            return
        favs = set(str(x) for x in app.local.get("favorites", []))
        for it in items:
            u = it["user"]
            uid = u.get("id")
            name = u.get("username") or "مستخدم"
            last = it["last"]
            if last:
                preview = preview_text(str(last.get("content", "")))
                if str(last.get("sender_id")) == str(app.user_id):
                    preview = "أنت: " + preview
                tm = local_hhmm(last.get("created_at", ""))
            else:
                preview, tm = "ابدأ محادثة جديدة", ""
            fav = str(uid) in favs
            row = self.make_chat_row(
                name, preview, tm, it["online"], u.get("avatar_url", ""), uid,
                unread=it["unread"], favorite=fav, status=(u.get("status") or "").strip())
            row.long_cb = lambda w, _u=str(uid): self.toggle_favorite(_u)
            box.add_widget(row)
            self._chat_items.append({
                "widget": row, "name": name, "preview": preview,
                "unread": it["unread"], "fav": fav,
            })
        self.apply_filters()

    def toggle_favorite(self, uid):
        app = self.app()
        favs = [str(x) for x in app.local.get("favorites", [])]
        if uid in favs:
            favs.remove(uid)
        else:
            favs.append(uid)
        app.local["favorites"] = favs
        save_local(app.local)
        self.render_chats()

    def make_chat_row(self, name, preview, tm, online, avatar_url, uid,
                      unread=0, favorite=False, status=""):
        app = self.app()
        row = ListRow(
            size_hint_y=None, height=dp(82), spacing=dp(10),
            padding=[dp(12), dp(8), dp(12), dp(8)], fill=CARD,
        )

        # يسار: الوقت + (عدّاد غير المقروء أو حالة الاتصال)
        left = BoxLayout(orientation="vertical", size_hint_x=None,
                         width=dp(64), padding=[0, dp(8)], spacing=dp(2))
        left.add_widget(app.label(tm, 11, ACCENT if unread else MUTED, halign="left"))
        if unread:
            badge_row = AnchorLayout(anchor_x="left", anchor_y="center")
            badge = Label(
                text=str(min(unread, 99)) + ("+" if unread > 99 else ""),
                font_name=FONT_PATH, font_size="11sp", color=WHITE,
                size_hint=(None, None), size=(dp(26), dp(22)))
            with badge.canvas.before:
                Color(1, 1, 1, 1)
                bshape = RoundedRectangle(radius=[dp(11)], texture=accent_tex())
            badge.bind(pos=lambda w, *_a, s=bshape: setattr(s, "pos", w.pos),
                       size=lambda w, *_a, s=bshape: setattr(s, "size", w.size))
            badge_row.add_widget(badge)
            left.add_widget(badge_row)
        else:
            left.add_widget(app.label(
                "متصل" if online else "غير متصل", 10,
                GREEN if online else MUTED, halign="left"))
        row.add_widget(left)

        # الوسط: الاسم (+ نجمة المفضلة) + آخر رسالة
        txt = BoxLayout(orientation="vertical", spacing=dp(2), padding=[0, dp(10)])
        name_row = BoxLayout(size_hint_y=1, spacing=dp(4))
        name_row.add_widget(app.label(name, 17, TEXT, halign="right", shorten=True))
        if favorite:
            name_row.add_widget(anchor(
                Icon("star", GOLD, size_hint=(None, None), size=(dp(22), dp(22))), dp(22)))
        txt.add_widget(name_row)
        fresh = preview == "ابدأ محادثة جديدة"
        txt.add_widget(app.label(
            preview, 13,
            MUTED if fresh else (TEXT if unread else hexa("#CFC4DE")),
            halign="right", shorten=True))
        row.add_widget(txt)

        # يمين: الصورة + نقطة الاتصال
        holder = FloatLayout(size_hint_x=None, width=dp(58))
        avatar = CircularAvatar(
            source=avatar_url or "", size=(dp(56), dp(56)), ring=online,
            initial=name, size_hint=(None, None),
            pos_hint={"center_x": .5, "center_y": .5})
        holder.add_widget(avatar)
        dot = Widget(size_hint=(None, None), size=(dp(15), dp(15)),
                     pos_hint={"right": 1, "y": .04})
        with dot.canvas:
            Color(*CARD)
            ring_c = Ellipse(pos=dot.pos, size=dot.size)
            Color(*(GREEN if online else MUTED))
            dot_c = Ellipse(pos=dot.pos, size=dot.size)

        def sync_dot(w, *_):
            ring_c.pos, ring_c.size = w.pos, w.size
            dot_c.pos = (w.x + dp(2.5), w.y + dp(2.5))
            dot_c.size = (w.width - dp(5), w.height - dp(5))

        dot.bind(pos=sync_dot, size=sync_dot)
        holder.add_widget(dot)
        row.add_widget(holder)

        def tapped(*_):
            if row.long_fired:
                row.long_fired = False
                return
            self.open_chat(uid, name, avatar_url, status)

        row.bind(on_release=tapped)
        return row

    def open_chat(self, uid, name, avatar_url="", status=""):
        chat = self.manager.get_screen('chat')
        chat.other_user_id = uid
        chat.other_username = name
        chat.other_avatar = avatar_url or ""
        chat.other_status = status or ""
        chat.open_real_chat()
        self.go('chat')


class ChatScreen(BaseScreen):
    other_user_id = None
    other_username = ""
    other_avatar = ""
    other_status = ""
    _row_info = None
    _loading_msgs = False
    _marking = False
    chat_id = None
    refresh_event = None
    _rendered = None

    def on_pre_leave(self, *_):
        self.stop_refresh()

    def stop_refresh(self):
        if self.refresh_event:
            self.refresh_event.cancel()
            self.refresh_event = None

    def open_real_chat(self):
        app = self.app()
        self.ids.title.text = self.other_username
        # تصفير المحادثة السابقة
        self._rendered = set()
        self._row_info = {}
        self._loading_msgs = False
        self._marking = False
        self.ids.messages.clear_widgets()
        VoicePlayer.stop()
        self.set_header_avatar()
        self.ids.chat_status.text = ar(self.other_status or "محادثة خاصة")
        try:
            self.chat_id = self.find_conversation()
            if not self.chat_id:
                self.chat_id = self.create_conversation()
            if not self.chat_id:
                app.error("تعذر فتح المحادثة. تحقق من صلاحيات Supabase.")
                return
            self.load_messages()
            self.stop_refresh()
            self.refresh_event = Clock.schedule_interval(
                lambda dt: self.load_messages(), 2
            )
        except Exception as exc:
            app.error("خطأ في المحادثة.\n" + str(exc))

    def find_conversation(self):
        app = self.app()
        me, other = str(app.user_id), str(self.other_user_id)
        r = requests.get(
            SUPABASE_URL + "/rest/v1/conversation_members?select=conversation_id,user_id&user_id=in.("
            + me + "," + other + ")",
            headers=headers(app.token), timeout=15,
        )
        if r.status_code != 200:
            return None
        seen = {}
        for row in r.json():
            seen.setdefault(str(row.get("conversation_id")), set()).add(str(row.get("user_id")))
        for cid, members in seen.items():
            if me in members and other in members:
                return cid
        return None

    def create_conversation(self):
        app = self.app()
        r = requests.post(
            SUPABASE_URL + "/rest/v1/rpc/create_private_conversation",
            headers=headers(app.token),
            json={"other_user_id": self.other_user_id},
            timeout=15,
        )
        if r.status_code not in (200, 201):
            print("Create conversation error:", r.text)
            return None
        data = r.json()
        if isinstance(data, str):
            return data
        if isinstance(data, dict):
            return data.get("create_private_conversation") or data.get("id")
        if isinstance(data, list) and data:
            return data[0] if isinstance(data[0], str) else data[0].get("id")
        return None

    def load_messages(self):
        app = self.app()
        if not self.chat_id or not app.token or self._loading_msgs:
            return
        self._loading_msgs = True
        cid = self.chat_id

        def work():
            r = requests.get(
                SUPABASE_URL + "/rest/v1/messages?select=*&conversation_id=eq."
                + str(cid) + "&order=created_at.desc&limit=100",
                headers=headers(app.token), timeout=15,
            )
            if r.status_code != 200:
                raise RuntimeError(r.text)
            data = r.json()
            data.reverse()
            return data

        def done(data, err):
            self._loading_msgs = False
            if err:
                print("Load messages exception:", err)
                return
            if cid != self.chat_id or data is None:
                return
            self.render_messages(data)
            self._mark_read(data)

        run_bg(work, done)

    def _mark_read(self, msgs):
        """يعلّم رسائل الطرف الآخر كمقروءة (يتطلب عمود read_at)."""
        app = self.app()
        me = str(app.user_id)
        need = [m for m in msgs
                if str(m.get("sender_id")) != me and "read_at" in m and not m.get("read_at")]
        if not need or self._marking:
            return
        self._marking = True
        cid = self.chat_id

        def work():
            requests.patch(
                SUPABASE_URL + "/rest/v1/messages?conversation_id=eq." + str(cid)
                + "&sender_id=neq." + me + "&read_at=is.null",
                headers={**headers(app.token), "Prefer": "return=minimal"},
                json={"read_at": datetime.now(timezone.utc).isoformat()},
                timeout=15,
            )

        run_bg(work, lambda res, err: setattr(self, "_marking", False))

    def set_header_avatar(self):
        holder = self.ids.chat_avatar_holder
        holder.clear_widgets()
        holder.add_widget(CircularAvatar(
            source=self.other_avatar or "", size=(dp(46), dp(46)), ring=False,
            initial=self.other_username, size_hint=(None, None)))

    def render_messages(self, messages):
        """يضيف الجديد فقط، ويحدّث حالة القراءة، ويزيل المحذوف."""
        if self._row_info is None:
            self._row_info = {}
        box = self.ids.messages
        app = self.app()
        added = False
        fetched = set()
        oldest = None
        for msg in messages:
            key = self._msg_key(msg)
            fetched.add(key)
            if oldest is None:
                oldest = str(msg.get("created_at"))
            info = self._row_info.get(key)
            if info is not None:
                if info["status"] is not None and msg.get("read_at"):
                    self._set_seen(info["status"])
                    info["status"] = None
                continue
            row, status = self._build_row(msg, app, key)
            self._row_info[key] = {
                "row": row, "ts": str(msg.get("created_at")), "status": status}
            if row is not None:
                box.add_widget(row)
                added = True
        # رسائل حُذفت من الطرف الآخر
        for key, info in list(self._row_info.items()):
            if (info["row"] is not None and key not in fetched
                    and oldest is not None and info["ts"] >= oldest):
                if info["row"].parent:
                    info["row"].parent.remove_widget(info["row"])
                del self._row_info[key]
        if added:
            Clock.schedule_once(lambda dt: setattr(self.ids.scroll, "scroll_y", 0), .1)

    def _build_row(self, msg, app, key):
        content = str(msg.get("content", "")).strip()
        if not content:
            return None, None
        kind, value, dur = parse_media(content)
        mine = str(msg.get("sender_id")) == str(app.user_id)
        tm = local_hhmm(msg.get("created_at", ""))

        max_width = min(dp(340), Window.width * .76)
        pad_x = dp(15)
        row = BoxLayout(
            orientation="horizontal", size_hint_y=None, size_hint_x=1,
            spacing=dp(4), padding=[dp(10), dp(3), dp(10), dp(3)],
        )

        # ── محتوى الفقاعة حسب النوع ──
        if kind == "image":
            width = min(max_width, dp(240))
            pad = [dp(4), dp(4), dp(4), dp(6)]
            inner = make_tap_image(value)
            inner.height = dp(200)
            inner.bind(on_release=lambda *_: show_image_viewer(value))
            inner_h = dp(200) + dp(8)
        elif kind == "voice":
            width = min(max_width, dp(230))
            pad = [pad_x, dp(9), pad_x, dp(6)]
            inner = BoxLayout(orientation="horizontal", size_hint=(1, None),
                              height=dp(44), spacing=dp(8))
            secs = max(0, dur)
            inner.add_widget(Label(
                text="%d:%02d" % (secs // 60, secs % 60), font_name=FONT_PATH,
                font_size="12sp", color=WHITE if mine else MUTED,
                size_hint_x=None, width=dp(38)))
            bar = VoiceBar(
                track=(1, 1, 1, .32) if mine else (1, 1, 1, .14),
                fill=WHITE if mine else ACCENT)
            inner.add_widget(bar)
            btn = IconButton(
                "play", color=(ACCENT if mine else WHITE),
                bg=(1, 1, 1, 1) if mine else ACCENT, size=(dp(40), dp(40)))
            ui = VoiceUI(btn, bar)
            btn.bind(on_release=lambda *_: VoicePlayer.toggle(value, ui))
            inner.add_widget(anchor(btn, dp(40)))
            inner_h = dp(44)
        else:
            pad = [pad_x, dp(9), pad_x, dp(6)]
            estimated = max(dp(78), min(max_width, len(value) * dp(8.8) + pad_x * 2))
            if "\n" in value:
                estimated = min(max_width, max(estimated, dp(120)))
            if mine and tm:
                estimated = min(max_width, max(estimated, dp(138)))
            width = estimated
            inner = Label(
                text=ar(value), font_name=FONT_PATH, font_size=dp(16),
                color=WHITE if mine else TEXT, halign="right", valign="middle",
                size_hint=(1, None),
                text_size=(max(dp(35), width - pad_x * 2), None),
            )
            inner.bind(texture_size=lambda w, *_: setattr(w, "height", max(dp(24), w.texture_size[1])))
            inner.height = max(dp(24), inner.texture_size[1])
            inner_h = None

        bubble = PressBox(
            orientation="vertical", size_hint=(None, None), width=width,
            padding=pad, spacing=dp(1),
        )
        if mine and msg.get("id"):
            bubble.long_cb = lambda w, k=key, mid=msg.get("id"): self.confirm_delete(k, mid)
        with bubble.canvas.before:
            if mine:
                Color(1, 1, 1, 1)
                shape = RoundedRectangle(
                    pos=bubble.pos, size=bubble.size,
                    radius=[dp(20), dp(20), dp(5), dp(20)], texture=accent_tex())
            else:
                Color(*CARD2)
                shape = RoundedRectangle(
                    pos=bubble.pos, size=bubble.size,
                    radius=[dp(20), dp(20), dp(20), dp(5)])
        bubble.bind(
            pos=lambda w, *_a, s=shape: setattr(s, "pos", w.pos),
            size=lambda w, *_a, s=shape: setattr(s, "size", w.size),
        )
        bubble.add_widget(inner)

        status_lbl = None
        if tm:
            meta = BoxLayout(orientation="horizontal", size_hint=(1, None),
                             height=dp(18), spacing=dp(4))
            if mine:
                seen = bool(msg.get("read_at"))
                status_lbl = Label(
                    text=ar("تمت القراءة" if seen else "تم الإرسال"),
                    font_name=FONT_PATH, font_size="10sp",
                    color=(1, 1, 1, .98) if seen else (1, 1, 1, .7),
                    halign="left", valign="middle",
                    size_hint_x=None, width=dp(72), text_size=(dp(72), dp(18)),
                    shorten=True, shorten_from="right")
                meta.add_widget(status_lbl)
            else:
                meta.add_widget(Widget())
            meta.add_widget(Label(
                text=tm, font_name=FONT_PATH, font_size="10sp",
                color=(1, 1, 1, .78) if mine else MUTED,
                halign="right", valign="middle", size_hint_x=None, width=dp(48),
                text_size=(dp(48), dp(18))))
            bubble.add_widget(meta)

        body_h = inner_h if inner_h is not None else inner.height
        bubble.height = max(dp(50), body_h + pad[1] + pad[3] + (dp(18) if tm else 0) + dp(2))
        row.height = bubble.height + dp(6)

        if mine:
            row.add_widget(Widget())
            row.add_widget(bubble)
        else:
            row.add_widget(bubble)
            row.add_widget(Widget())
        return row, (None if (status_lbl is None or msg.get("read_at")) else status_lbl)

    def _msg_key(self, msg):
        return str(msg.get("id") or (str(msg.get("created_at")) + str(msg.get("content"))))

    def _set_seen(self, label):
        label.text = ar("تمت القراءة")
        label.color = (1, 1, 1, .98)

    def confirm_delete(self, key, mid):
        app = self.app()
        box = BoxLayout(orientation="vertical", padding=dp(16), spacing=dp(14))
        box.add_widget(app.label("هل تريد حذف هذه الرسالة؟", 16, TEXT))
        btns = BoxLayout(size_hint_y=None, height=dp(50), spacing=dp(10))
        cancel = DarkButton(text="إلغاء")
        delete = DarkButton(text="حذف", fill=DANGER_FILL, border=DANGER_BORDER, color=DANGER_TXT)
        btns.add_widget(cancel)
        btns.add_widget(delete)
        box.add_widget(btns)
        pop = StyledPopup(title=ar("حذف الرسالة"), content=box, size_hint=(.86, .34))
        cancel.bind(on_release=pop.dismiss)

        def do_delete(*_):
            pop.dismiss()

            def work():
                r = requests.delete(
                    SUPABASE_URL + "/rest/v1/messages?id=eq." + str(mid),
                    headers={**headers(app.token), "Prefer": "return=representation"},
                    timeout=15)
                if r.status_code not in (200, 204):
                    raise RuntimeError(r.text)
                if r.status_code == 200 and not r.json():
                    raise RuntimeError("لا تملك صلاحية الحذف. شغّل ملف SQL الجديد في Supabase.")

            def done(res, err):
                if err:
                    app.error("تعذر حذف الرسالة.\n" + str(err))
                    return
                info = self._row_info.pop(key, None)
                if info and info["row"] is not None and info["row"].parent:
                    info["row"].parent.remove_widget(info["row"])

            run_bg(work, done)

        delete.bind(on_release=do_delete)
        pop.open()

    # ── الإرسال ──
    def _post(self, content):
        app = self.app()
        r = requests.post(
            SUPABASE_URL + "/rest/v1/messages",
            headers={**headers(app.token), "Prefer": "return=representation"},
            json={
                "conversation_id": self.chat_id,
                "sender_id": app.user_id,
                "content": content,
            },
            timeout=20,
        )
        if r.status_code not in (200, 201):
            raise RuntimeError(r.text)

    def send(self):
        text = self.ids.message.text.strip()
        if not text or not self.chat_id:
            return
        app = self.app()
        try:
            self._post(text)
            self.ids.message.text = ""
            self.load_messages()
        except Exception as exc:
            app.error("تعذر إرسال الرسالة.\n" + str(exc))

    def _after_media(self, busy, err):
        busy.dismiss()
        if err:
            self.app().error("تعذر إرسال الوسائط.\n" + str(err))
        else:
            self.load_messages()

    def send_image(self, path):
        app = self.app()
        if not self.chat_id:
            return
        busy = app.busy("جاري إرسال الصورة...")
        chat_id = self.chat_id

        def work():
            data, ctype, ext = prepare_image_bytes(path)
            url = storage_upload(app.token, MEDIA_BUCKET,
                                 "%s/%s.%s" % (chat_id, uuid.uuid4().hex, ext), data, ctype)
            self._post(MEDIA_IMG + url)

        run_bg(work, lambda res, err: self._after_media(busy, err))

    def send_voice(self, path, secs):
        app = self.app()
        if not self.chat_id:
            return
        busy = app.busy("جاري إرسال الرسالة الصوتية...")
        chat_id = self.chat_id

        def work():
            with open(path, "rb") as f:
                data = f.read()
            url = storage_upload(app.token, MEDIA_BUCKET,
                                 "%s/%s.m4a" % (chat_id, uuid.uuid4().hex), data, "audio/mp4")
            self._post(MEDIA_VOICE + url + "|" + str(secs))

        run_bg(work, lambda res, err: self._after_media(busy, err))

    # ── الصور: معرض / كاميرا ──
    def pick_photo(self):
        NativeMedia.pick_image(
            self.send_image, lambda msg: choose_image_file(self.send_image))

    def take_photo(self):
        app = self.app()

        def go(ok):
            if not ok:
                app.error("اسمح للتطبيق باستخدام الكاميرا من إعدادات الجهاز.")
                return
            NativeMedia.take_photo(
                self.send_image,
                lambda msg: app.error("تعذر فتح الكاميرا.\n" + msg)
                if msg != "desktop" else choose_image_file(self.send_image))

        ask_permissions(["android.permission.CAMERA"], go)

    # ── الصوت ──
    def start_voice(self):
        app = self.app()

        def go(ok):
            if not ok:
                app.error("اسمح للتطبيق باستخدام المايكروفون من إعدادات الجهاز.")
                return
            self._begin_voice()

        ask_permissions(["android.permission.RECORD_AUDIO"], go)

    def _begin_voice(self):
        app = self.app()
        VoicePlayer.stop()
        rec = VoiceRecorder()
        try:
            rec.start()
        except Exception as exc:
            app.error("تعذر بدء التسجيل.\n" + str(exc))
            return
        box = BoxLayout(orientation="vertical", padding=dp(16), spacing=dp(12))
        box.add_widget(app.label("جاري التسجيل...", 15, TEXT, size_hint_y=None, height=dp(26)))
        timer = app.label("0:00", 34, ACCENT, size_hint_y=None, height=dp(56))
        box.add_widget(timer)
        box.add_widget(Widget())
        btns = BoxLayout(size_hint_y=None, height=dp(52), spacing=dp(10))
        cancel = DarkButton(text="إلغاء")
        send = GoldButton(text="إرسال")
        btns.add_widget(cancel)
        btns.add_widget(send)
        box.add_widget(btns)
        pop = StyledPopup(title=ar("رسالة صوتية"), content=box,
                          size_hint=(.86, .4), auto_dismiss=False)

        def finish(send_it):
            ev.cancel()
            pop.dismiss()
            if send_it:
                path, secs = rec.stop()
                if secs >= 1:
                    self.send_voice(path, secs)
                else:
                    app.notice("التسجيل قصير جداً.")
            else:
                rec.discard()

        def tick(_dt):
            secs = int(time.time() - rec.t0)
            timer.text = "%d:%02d" % (secs // 60, secs % 60)
            if secs >= MAX_VOICE_SECONDS:
                finish(True)

        ev = Clock.schedule_interval(tick, .5)
        cancel.bind(on_release=lambda *_: finish(False))
        send.bind(on_release=lambda *_: finish(True))
        pop.open()

    def chat_actions(self):
        app = self.app()
        box = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(8))
        block = DarkButton(text="حظر المستخدم", size_hint_y=None, height=dp(52))
        report = DarkButton(text="إبلاغ عن المستخدم", size_hint_y=None, height=dp(52))
        cancel = GoldButton(text="إلغاء", size_hint_y=None, height=dp(52))
        box.add_widget(block); box.add_widget(report); box.add_widget(cancel)
        pop = StyledPopup(title=ar("إجراءات المحادثة"), content=box, size_hint=(.9, .42))

        def do_block(*_):
            try:
                r = requests.post(
                    SUPABASE_URL + "/rest/v1/blocked_users",
                    headers={**headers(app.token), "Prefer": "return=minimal"},
                    json={"user_id": app.user_id, "blocked_user_id": self.other_user_id},
                    timeout=15
                )
                if r.status_code in (200, 201):
                    pop.dismiss()
                    app.notice("تم حظر المستخدم.")
                else:
                    app.error("تعذر تنفيذ الحظر.\n" + r.text)
            except Exception as exc:
                app.error("تعذر الاتصال بالخادم.\n" + str(exc))

        def do_report(*_):
            pop.dismiss()
            report_screen = self.manager.get_screen("report")
            report_screen.target_user_id = self.other_user_id
            self.go("report")

        block.bind(on_release=do_block)
        report.bind(on_release=do_report)
        cancel.bind(on_release=pop.dismiss)
        pop.open()

    def back(self):
        self.stop_refresh()
        self.go("home")


class ProfileScreen(BaseScreen):
    def on_pre_enter(self, *_):
        self.refresh()

    def refresh(self):
        app = self.app()
        username = app.username or app.local.get("username", "mohsen12")
        status_value = app.local.get("status", "...")

        self.ids.profile_name.text = username
        self.ids.info_username.text = username
        self.ids.status.text = ar(status_value)
        self.ids.join.text = app.local.get("join", "2025/09/16")

        # الصورة: الملف المحلي إن وُجد، وإلا الرابط المحفوظ على السيرفر
        src = str(app.local.get("avatar", ""))
        if not (src and os.path.exists(src)):
            src = str(app.local.get("avatar_url", ""))
        row = self.ids.avatar_row
        row.clear_widgets()
        avatar = CircularAvatar(size=(dp(120), dp(120)), ring=True, source=src,
                                initial=username, size_hint=(None, None))
        row.add_widget(avatar)
        self.ids.profile_avatar = avatar

    def _place_profile_avatar(self):
        hero = self.ids.profile_hero
        avatar = self.ids.profile_avatar
        avatar.pos = ((hero.width - avatar.width) / 2, dp(25))
        camera = self.ids.profile_camera
        camera.pos = (avatar.x + avatar.width - dp(12), avatar.y + dp(2))

    def edit_name(self):
        app = self.app()
        box = BoxLayout(orientation="vertical", padding=dp(14), spacing=dp(10))
        inp = TextInput(
            text=self.ids.profile_name.text, multiline=False,
            font_name=FONT_PATH, size_hint_y=None, height=dp(50),
            background_normal="", background_color=CARD,
            foreground_color=TEXT, hint_text_color=MUTED,
            halign="right"
        )
        ok = GoldButton(text="حفظ الاسم", size_hint_y=None, height=dp(50))
        cancel = DarkButton(text="إلغاء", size_hint_y=None, height=dp(50))
        box.add_widget(inp); box.add_widget(ok); box.add_widget(cancel)
        pop = StyledPopup(
            title=ar("تعديل اسم المستخدم"), content=box,
            size_hint=(.9, .42), auto_dismiss=False
        )

        def save_name(*_):
            value = inp.text.strip()
            if len(value) < 3 or " " in value:
                app.error("اسم المستخدم يجب أن يكون 3 أحرف على الأقل وبدون مسافات.")
                return
            try:
                r = requests.patch(
                    SUPABASE_URL + "/rest/v1/profiles?id=eq." + str(app.user_id),
                    headers={**headers(app.token), "Prefer": "return=minimal"},
                    json={"username": value}, timeout=15
                )
                if r.status_code not in (200, 204):
                    app.error("تعذر حفظ الاسم في قاعدة البيانات.\n" + r.text)
                    return
            except Exception as exc:
                app.error("تعذر الاتصال بالخادم.\n" + str(exc))
                return
            app.local["username"] = value
            app.username = value
            save_local(app.local)
            self.refresh()
            pop.dismiss()

        ok.bind(on_release=save_name)
        cancel.bind(on_release=pop.dismiss)
        pop.open()

    def edit_status(self):
        app = self.app()
        box = BoxLayout(orientation="vertical", padding=dp(14), spacing=dp(10))
        inp = TextInput(
            text=app.local.get("status", "..."), multiline=False,
            font_name=FONT_PATH, size_hint_y=None, height=dp(50),
            background_normal="", background_color=CARD,
            foreground_color=TEXT, hint_text_color=MUTED, halign="right"
        )
        ok = GoldButton(text="حفظ الحالة", size_hint_y=None, height=dp(50))
        cancel = DarkButton(text="إلغاء", size_hint_y=None, height=dp(50))
        box.add_widget(inp); box.add_widget(ok); box.add_widget(cancel)
        pop = StyledPopup(
            title=ar("تغيير الحالة الشخصية"), content=box,
            size_hint=(.9, .42), auto_dismiss=False
        )

        def save_status(*_):
            value = inp.text.strip() or "..."
            app.local["status"] = value
            save_local(app.local)
            app.sync_status(value)
            self.refresh()
            pop.dismiss()

        ok.bind(on_release=save_status)
        cancel.bind(on_release=pop.dismiss)
        pop.open()

    def choose_photo(self):
        app = self.app()
        box = BoxLayout(orientation="vertical", padding=dp(14), spacing=dp(10))
        cam = GoldButton(text="التقاط صورة بالكاميرا", size_hint_y=None, height=dp(52))
        gal = DarkButton(text="اختيار من المعرض", size_hint_y=None, height=dp(52))
        cancel = DarkButton(text="إلغاء", size_hint_y=None, height=dp(48))
        box.add_widget(cam)
        box.add_widget(gal)
        box.add_widget(cancel)
        pop = StyledPopup(title=ar("الصورة الشخصية"), content=box, size_hint=(.9, .46))

        def from_cam(*_):
            pop.dismiss()

            def go(ok):
                if not ok:
                    app.error("اسمح للتطبيق باستخدام الكاميرا من إعدادات الجهاز.")
                    return
                NativeMedia.take_photo(
                    self.set_avatar,
                    lambda msg: app.error("تعذر فتح الكاميرا.\n" + msg)
                    if msg != "desktop" else choose_image_file(self.set_avatar))

            ask_permissions(["android.permission.CAMERA"], go)

        def from_gal(*_):
            pop.dismiss()
            NativeMedia.pick_image(
                self.set_avatar, lambda msg: choose_image_file(self.set_avatar))

        cam.bind(on_release=from_cam)
        gal.bind(on_release=from_gal)
        cancel.bind(on_release=pop.dismiss)
        pop.open()

    def set_avatar(self, path):
        """يرفع الصورة إلى Storage ويحفظ رابطها في profiles ليراها الجميع."""
        app = self.app()
        busy = app.busy("جاري رفع الصورة...")

        def work():
            data, ctype, ext = prepare_image_bytes(path, max_side=640)
            url = storage_upload(app.token, AVATAR_BUCKET,
                                 "%s.%s" % (app.user_id, ext), data, ctype)
            url = url + "?v=%d" % int(time.time())
            r = requests.patch(
                SUPABASE_URL + "/rest/v1/profiles?id=eq." + str(app.user_id),
                headers={**headers(app.token), "Prefer": "return=minimal"},
                json={"avatar_url": url}, timeout=20)
            if r.status_code not in (200, 204):
                raise RuntimeError(r.text)
            return url

        def done(url, err):
            busy.dismiss()
            if err:
                app.error("تعذر رفع الصورة.\n" + str(err))
                return
            app.local["avatar"] = path
            app.local["avatar_url"] = url
            save_local(app.local)
            self.refresh()

        run_bg(work, done)


class UsersScreen(BaseScreen):
    def on_pre_enter(self, *_):
        self.load_users()


    def make_user_row(self, user):
        app = self.app()
        uid = user.get("id")
        name = user.get("username") or "مستخدم"
        online = app.is_online(user.get("last_seen"))
        avatar_url = user.get("avatar_url") or ""
        status = (user.get("status") or "").strip()
        if status in ("", "..."):
            status = ""

        row = ListRow(
            size_hint_y=None, height=dp(84), spacing=dp(10),
            padding=[dp(12), dp(8), dp(12), dp(8)], fill=CARD,
        )
        row.add_widget(anchor(
            Icon("chev", MUTED, size_hint=(None, None), size=(dp(26), dp(26))), dp(26)))

        info = BoxLayout(orientation="vertical", spacing=dp(1), padding=[0, dp(12)])
        info.add_widget(app.label(name, 18, TEXT, halign="right", shorten=True))
        info.add_widget(app.label(
            status or ("متصل الآن" if online else "غير متصل"), 12,
            GREEN if (online and not status) else MUTED, halign="right", shorten=True))
        row.add_widget(info)

        holder = FloatLayout(size_hint_x=None, width=dp(62))
        avatar = CircularAvatar(
            source=avatar_url, size=(dp(60), dp(60)), ring=online,
            initial=name, size_hint=(None, None),
            pos_hint={"center_x": .5, "center_y": .5})
        holder.add_widget(avatar)
        dot = Widget(size_hint=(None, None), size=(dp(16), dp(16)),
                     pos_hint={"right": 1, "y": .03})
        with dot.canvas:
            Color(*CARD)
            ring_c = Ellipse(pos=dot.pos, size=dot.size)
            Color(*(GREEN if online else MUTED))
            dot_c = Ellipse(pos=dot.pos, size=dot.size)

        def sync_dot(w, *_):
            ring_c.pos, ring_c.size = w.pos, w.size
            dot_c.pos = (w.x + dp(2.5), w.y + dp(2.5))
            dot_c.size = (w.width - dp(5), w.height - dp(5))

        dot.bind(pos=sync_dot, size=sync_dot)
        holder.add_widget(dot)
        row.add_widget(holder)

        row.bind(on_release=lambda *_: self.open_chat(uid, name, avatar_url, status))
        return row

    def load_users(self):
        app = self.app()
        if not app.token:
            self.go("login")
            return
        box = self.ids.users_list
        if not box.children:
            box.add_widget(app.label("جاري التحميل...", 16, MUTED,
                                     size_hint_y=None, height=dp(100)))

        def done(users, err):
            box.clear_widgets()
            if err:
                app.error("تعذر الاتصال بالخادم.\n" + str(err))
                return
            if not users:
                box.add_widget(app.label("لا يوجد مستخدمون آخرون حالياً.", 17, MUTED,
                                         size_hint_y=None, height=dp(100)))
                return
            for user in users:
                box.add_widget(self.make_user_row(user))

        run_bg(lambda: fetch_profiles(app), done)

    def open_chat(self, uid, name, avatar_url="", status=""):
        chat = self.manager.get_screen("chat")
        chat.other_user_id = uid
        chat.other_username = name
        chat.other_avatar = avatar_url or ""
        chat.other_status = status or ""
        chat.open_real_chat()
        self.go("chat")


class BlockedUsersScreen(BaseScreen):
    def on_pre_enter(self, *_):
        self.load_blocked()

    def load_blocked(self):
        box = self.ids.blocked_list
        box.clear_widgets()
        app = self.app()
        if not app.token:
            self.go("login")
            return
        try:
            r = requests.get(
                SUPABASE_URL + "/rest/v1/blocked_users?select=id,blocked_user_id,blocked_profile:profiles!blocked_users_blocked_user_id_fkey(id,username)&user_id=eq."
                + str(app.user_id),
                headers=headers(app.token), timeout=15
            )
            if r.status_code != 200:
                box.add_widget(app.label(
                    "لا توجد قائمة حظر جاهزة في قاعدة البيانات حالياً.",
                    15, MUTED, size_hint_y=None, height=dp(80)
                ))
                return
            rows = r.json()
            if not rows:
                box.add_widget(app.label(
                    "قائمة المحظورين فارغة.", 16, MUTED,
                    size_hint_y=None, height=dp(80)
                ))
                return
            for row in rows:
                profile = row.get("blocked_profile") or {}
                name = profile.get("username", "مستخدم")
                b = ActionRow(name, "اضغط لإلغاء الحظر", icon="block")
                b.bind(on_release=lambda _, uid=row.get("blocked_user_id"): self.unblock(uid))
                box.add_widget(b)
        except Exception as exc:
            box.add_widget(app.label(
                "تعذر تحميل قائمة الحظر.", 15, MUTED,
                size_hint_y=None, height=dp(80)
            ))
            print("Blocked users:", exc)

    def unblock(self, uid):
        app = self.app()
        if not uid:
            return
        try:
            r = requests.delete(
                SUPABASE_URL + "/rest/v1/blocked_users?user_id=eq."
                + str(app.user_id) + "&blocked_user_id=eq." + str(uid),
                headers=headers(app.token), timeout=15
            )
            if r.status_code in (200, 204):
                self.load_blocked()
            else:
                app.error("تعذر إلغاء الحظر.\n" + r.text)
        except Exception as exc:
            app.error("تعذر الاتصال بالخادم.\n" + str(exc))


class ReportScreen(BaseScreen):
    def submit(self, reason):
        app = self.app()
        target = getattr(self, "target_user_id", None)
        if not target or not app.token:
            app.error("لا يوجد مستخدم للإبلاغ عنه.")
            return
        try:
            r = requests.post(
                SUPABASE_URL + "/rest/v1/reports",
                headers={**headers(app.token), "Prefer": "return=minimal"},
                json={
                    "reporter_id": app.user_id,
                    "reported_user_id": target,
                    "reason": reason,
                },
                timeout=15
            )
            if r.status_code in (200, 201):
                app.notice("تم إرسال البلاغ.")
                self.go("chat")
            else:
                app.error("تعذر إرسال البلاغ.\n" + r.text)
        except Exception as exc:
            app.error("تعذر الاتصال بالخادم.\n" + str(exc))


class PrivacyScreen(BaseScreen):
    def back(self):
        self.go("settings")



class SettingsScreen(BaseScreen):
    def logout(self):
        self.app().logout()

    def users(self):
        self.go("users")

    def profile(self):
        self.go("profile")

    def blocked(self):
        self.go("blocked")

    def privacy(self):
        self.go("privacy")

    def report(self, target_user_id):
        screen = self.manager.get_screen("report")
        screen.target_user_id = target_user_id
        self.go("report")

class ALWardApp(App):
    def build(self):
        self.title = "AL WARD"
        self.token = None
        self.user_id = None
        self.username = None
        self.presence_event = None
        self.local = load_local()

        sm = ScreenManager(transition=FadeTransition(duration=.12))
        sm.add_widget(self.make_login())
        sm.add_widget(self.make_signup())
        sm.add_widget(self.make_home())
        sm.add_widget(self.make_chat())
        sm.add_widget(self.make_profile())
        sm.add_widget(self.make_users())
        sm.add_widget(self.make_settings())
        sm.add_widget(self.make_blocked())
        sm.add_widget(self.make_privacy())
        sm.add_widget(self.make_report())
        sm.current = "login"
        return sm


    # ───────────────────────── أساسيات التصميم ─────────────────────────
    def base_root(self):
        root = BoxLayout(
            orientation="vertical",
            padding=[dp(14), dp(12), dp(14), dp(10)],
            spacing=dp(10),
        )
        paint_background(root)
        return root

    def panel(self):
        root = self.base_root()
        root.add_widget(Widget())
        return root

    def label(self, text, size=16, color=TEXT, **kwargs):
        kwargs.setdefault("font_name", FONT_PATH)
        kwargs.setdefault("font_size", dp(size))
        kwargs.setdefault("color", color)
        kwargs.setdefault("halign", "center")
        kwargs.setdefault("valign", "middle")
        lbl = Label(text=ar(text), **kwargs)
        if kwargs["halign"] != "center" and "text_size" not in kwargs:
            lbl.bind(size=lambda w, v: setattr(w, "text_size", v))
        return lbl

    def field(self, hint, password=False, height=54):
        box = FieldBox(hint=hint, password=password, height=height)
        return box, box.input

    def auth_card(self, height):
        return Card(
            orientation="vertical", size_hint_y=None, height=dp(height),
            padding=[dp(18), dp(18)], spacing=dp(10), fill=CARD, radius=26,
        )

    # ───────────────────────── تسجيل الدخول / إنشاء حساب ─────────────────────────
    def make_login(self):
        s = LoginScreen(name="login")
        root = self.panel()

        logo_row = AnchorLayout(size_hint_y=None, height=dp(104))
        logo_row.add_widget(RoseLogo(size=(dp(100), dp(100))))
        root.add_widget(logo_row)
        root.add_widget(self.label("AL WARD", 32, TEXT, size_hint_y=None, height=dp(48)))
        root.add_widget(self.label("تواصل بأناقة", 14, MUTED, size_hint_y=None, height=dp(26)))
        root.add_widget(Widget(size_hint_y=None, height=dp(6)))

        card = self.auth_card(372)
        card.add_widget(self.label("تسجيل الدخول", 21, TEXT, size_hint_y=None, height=dp(34)))
        card.add_widget(self.label("ادخل إلى حسابك للمتابعة", 13, MUTED,
                                   size_hint_y=None, height=dp(22)))
        ubox, u = self.field("اسم المستخدم")
        pbox, p = self.field("كلمة المرور", password=True)
        s.ids.username = u
        s.ids.password = p
        card.add_widget(ubox)
        card.add_widget(pbox)

        login = GoldButton(text="تسجيل الدخول", size_hint_y=None, height=dp(54))
        login.bind(on_release=lambda *_: s.login())
        s.ids.login_btn = login
        create = DarkButton(text="إنشاء حساب جديد", size_hint_y=None, height=dp(50))
        create.bind(on_release=lambda *_: s.create_account())
        card.add_widget(login)
        card.add_widget(create)
        root.add_widget(card)
        root.add_widget(Widget())
        s.add_widget(root)
        return s

    def make_signup(self):
        s = SignupScreen(name="signup")
        root = self.panel()

        logo_row = AnchorLayout(size_hint_y=None, height=dp(76))
        logo_row.add_widget(RoseLogo(size=(dp(72), dp(72))))
        root.add_widget(logo_row)
        root.add_widget(self.label("AL WARD", 26, TEXT, size_hint_y=None, height=dp(38)))
        root.add_widget(Widget(size_hint_y=None, height=dp(4)))

        card = self.auth_card(398)
        card.add_widget(self.label("إنشاء حساب جديد", 21, TEXT, size_hint_y=None, height=dp(34)))
        card.add_widget(self.label("انضم إلى AL WARD في ثوانٍ", 13, MUTED,
                                   size_hint_y=None, height=dp(22)))
        fields = []
        for hint, password in [
            ("اسم المستخدم", False),
            ("كلمة المرور", True),
            ("تأكيد كلمة المرور", True),
        ]:
            box, t = self.field(hint, password=password)
            fields.append(t)
            card.add_widget(box)
        s.ids.username, s.ids.password, s.ids.confirm = fields

        create = GoldButton(text="إنشاء الحساب", size_hint_y=None, height=dp(54))
        create.bind(on_release=lambda *_: s.create())
        back = DarkButton(text="العودة لتسجيل الدخول", size_hint_y=None, height=dp(48))
        back.bind(on_release=lambda *_: s.go("login"))
        card.add_widget(create)
        card.add_widget(back)
        root.add_widget(card)
        root.add_widget(Widget())
        s.add_widget(root)
        return s

    # ───────────────────────── الرئيسية ─────────────────────────
    def make_home(self):
        s = HomeScreen(name='home')
        root = self.base_root()

        top = BoxLayout(size_hint_y=None, height=dp(66), spacing=dp(10))
        settings = IconButton("sliders", color=TEXT, bg=CARD2)
        settings.bind(on_release=lambda *_: self.goto('settings'))
        top.add_widget(anchor(settings, dp(44)))
        top.add_widget(Widget())
        titles = BoxLayout(orientation="vertical", size_hint_x=None,
                           width=dp(150), padding=[0, dp(8)])
        titles.add_widget(self.label("AL WARD", 24, TEXT, halign="right"))
        titles.add_widget(self.label("محادثاتك الخاصة", 12, MUTED, halign="right"))
        top.add_widget(titles)
        top.add_widget(anchor(RoseLogo(size=(dp(50), dp(50))), dp(50)))
        root.add_widget(top)

        sbox, search = self.field('البحث في المحادثات...', height=50)
        search.bind(text=lambda w, value: s.filter_chats(value))
        root.add_widget(sbox)

        tabs = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(8))
        for key, label_text in (('fav', 'المفضلة'), ('unread', 'غير مقروءة'), ('all', 'الكل')):
            tb = DarkButton(text=label_text, font_size='13sp')
            tb.bind(on_release=lambda _, k=key: s.set_tab(k))
            setattr(s.ids, 'tab_' + key, tb)
            tabs.add_widget(tb)
        s.ids.tab_all.set_active(True)
        root.add_widget(tabs)

        scroll = ScrollView(do_scroll_x=False, bar_width=dp(3),
                            bar_color=(ACCENT[0], ACCENT[1], ACCENT[2], .5))
        box = BoxLayout(orientation='vertical', size_hint_y=None,
                        spacing=dp(8), padding=[0, dp(2), 0, dp(6)])
        box.bind(minimum_height=box.setter('height'))
        s.ids.chat_list = box
        scroll.add_widget(box)
        root.add_widget(scroll)
        root.add_widget(self.bottom_nav('home'))
        s.add_widget(root)
        return s

    # ───────────────────────── المحادثة ─────────────────────────
    def make_chat(self):
        s = ChatScreen(name="chat")
        root = self.base_root()

        top = Card(size_hint_y=None, height=dp(70), padding=[dp(10), dp(8)],
                   spacing=dp(8), fill=PANEL, radius=22)
        more = IconButton("more", color=TEXT, bg=CARD2)
        more.bind(on_release=lambda *_: s.chat_actions())
        top.add_widget(anchor(more, dp(44)))

        title_box = BoxLayout(orientation="vertical", padding=[0, dp(8)])
        s.ids.title = self.label("المحادثة", 19, TEXT, halign="right")
        title_box.add_widget(s.ids.title)
        s.ids.chat_status = self.label("محادثة خاصة", 12, MUTED, halign="right", shorten=True)
        title_box.add_widget(s.ids.chat_status)
        top.add_widget(title_box)

        avatar_holder = AnchorLayout(size_hint=(None, 1), width=dp(50))
        s.ids.chat_avatar_holder = avatar_holder
        top.add_widget(avatar_holder)

        back = IconButton("back", color=TEXT, bg=CARD2)
        back.bind(on_release=lambda *_: s.back())
        top.add_widget(anchor(back, dp(44)))
        root.add_widget(top)

        scroll = ScrollView(do_scroll_x=False, bar_width=dp(3),
                            bar_color=(ACCENT[0], ACCENT[1], ACCENT[2], .5))
        box = BoxLayout(orientation="vertical", size_hint_y=None,
                        spacing=dp(4), padding=[0, dp(8)])
        box.bind(minimum_height=box.setter("height"))
        s.ids.messages = box
        s.ids.scroll = scroll
        scroll.add_widget(box)
        root.add_widget(scroll)

        # شريط الصور (يظهر عند الضغط على +)
        media_row = BoxLayout(size_hint_y=None, height=0, spacing=dp(8))
        media_row.opacity = 0
        media_row.disabled = True
        gallery = DarkButton(text="صورة من المعرض", font_size="13sp")
        gallery.bind(on_release=lambda *_: s.pick_photo())
        camera = DarkButton(text="كاميرا", font_size="13sp")
        camera.bind(on_release=lambda *_: s.take_photo())
        media_row.add_widget(gallery)
        media_row.add_widget(camera)
        root.add_widget(media_row)

        def toggle_media(*_):
            show = media_row.height == 0
            media_row.height = dp(42) if show else 0
            media_row.opacity = 1 if show else 0
            media_row.disabled = not show

        bar = Card(size_hint_y=None, height=dp(62), padding=[dp(8), dp(8)],
                   spacing=dp(6), fill=PANEL, radius=31)
        send = IconButton("send", color=WHITE, grad=True, size=(dp(46), dp(46)))
        send.bind(on_release=lambda *_: s.send())
        bar.add_widget(anchor(send, dp(46)))
        mic = IconButton("mic", color=ACCENT, bg=(ACCENT[0], ACCENT[1], ACCENT[2], .14),
                         size=(dp(44), dp(44)))
        mic.bind(on_release=lambda *_: s.start_voice())
        bar.add_widget(anchor(mic, dp(44)))
        fbox = FieldBox(hint="اكتب رسالة...", height=46, draw=False)
        fbox.size_hint_y = 1
        inp = fbox.input
        inp.bind(on_text_validate=lambda *_: s.send())
        s.ids.message = inp
        bar.add_widget(fbox)
        plus = IconButton("plus", color=ACCENT, bg=(ACCENT[0], ACCENT[1], ACCENT[2], .14),
                          size=(dp(44), dp(44)))
        plus.bind(on_release=toggle_media)
        bar.add_widget(anchor(plus, dp(44)))
        root.add_widget(bar)

        s.add_widget(root)
        return s

    # ───────────────────────── الملف الشخصي ─────────────────────────
    def make_profile(self):
        s = ProfileScreen(name="profile")
        root = self.base_root()
        root.add_widget(self.header("الملف الشخصي", lambda: s.go("home")))

        scroll = ScrollView(do_scroll_x=False, bar_width=dp(3),
                            bar_color=(ACCENT[0], ACCENT[1], ACCENT[2], .5))
        page = BoxLayout(orientation="vertical", size_hint_y=None,
                         spacing=dp(12), padding=[0, dp(4), 0, dp(14)])
        page.bind(minimum_height=page.setter("height"))

        hero = Card(orientation="vertical", size_hint_y=None, height=dp(310),
                    padding=[dp(14), dp(18), dp(14), dp(14)], spacing=dp(6),
                    radius=30, texture=gradient("hero", [HERO_A, HERO_B]),
                    border=(1, 1, 1, .14))
        s.ids.profile_hero = hero

        avatar_row = AnchorLayout(size_hint_y=None, height=dp(132))
        avatar = CircularAvatar(size=(dp(120), dp(120)), ring=True,
                                initial=self.local.get("username", "mohsen12"),
                                size_hint=(None, None))
        avatar_row.add_widget(avatar)
        s.ids.profile_avatar = avatar
        s.ids.avatar_row = avatar_row
        hero.add_widget(avatar_row)

        name = self.label(self.local.get("username", "mohsen12"), 25, WHITE,
                          size_hint_y=None, height=dp(40))
        s.ids.profile_name = name
        hero.add_widget(name)
        online = self.label("متصل الآن", 13, hexa("#9CF5CB"),
                            size_hint_y=None, height=dp(22))
        s.ids.online = online
        hero.add_widget(online)

        camera = GoldButton(text="تغيير الصورة", size_hint=(None, None),
                            size=(dp(176), dp(42)))
        camera.bind(on_release=lambda *_: s.choose_photo())
        s.ids.profile_camera = camera
        cam_row = AnchorLayout(size_hint_y=None, height=dp(48))
        cam_row.add_widget(camera)
        hero.add_widget(cam_row)
        page.add_widget(hero)

        # الحالة (اضغط للتعديل)
        status_card = ListRow(orientation="vertical", size_hint_y=None, height=dp(80),
                              padding=[dp(18), dp(12)], spacing=dp(2), fill=CARD, radius=20)
        status_card.add_widget(self.label("الحالة الشخصية", 12, MUTED, halign="right",
                                          size_hint_y=None, height=dp(20)))
        status = self.label(self.local.get("status", "..."), 16, TEXT, halign="right")
        s.ids.status = status
        status_card.add_widget(status)
        status_card.bind(on_release=lambda *_: s.edit_status())
        page.add_widget(status_card)

        # اسم المستخدم + تاريخ الانضمام
        info_row = BoxLayout(size_hint_y=None, height=dp(88), spacing=dp(10))

        def stat(caption, value_widget):
            c = Card(orientation="vertical", padding=[dp(16), dp(12)], spacing=dp(4),
                     fill=CARD, radius=20)
            c.add_widget(self.label(caption, 12, MUTED, halign="right",
                                    size_hint_y=None, height=dp(20)))
            c.add_widget(value_widget)
            return c

        info_name = self.label(self.local.get("username", "mohsen12"), 17, TEXT, halign="right")
        s.ids.info_username = info_name
        date = self.label(self.local.get("join", "2025/09/16"), 17, TEXT, halign="right")
        s.ids.join = date
        info_row.add_widget(stat("تاريخ الانضمام", date))
        info_row.add_widget(stat("اسم المستخدم", info_name))
        page.add_widget(info_row)

        edit = GoldButton(text="تعديل اسم المستخدم", size_hint_y=None, height=dp(54))
        edit.bind(on_release=lambda *_: s.edit_name())
        page.add_widget(edit)
        actions = BoxLayout(size_hint_y=None, height=dp(52), spacing=dp(10))
        photo_btn = DarkButton(text="تغيير الصورة")
        status_btn = DarkButton(text="تغيير الحالة")
        photo_btn.bind(on_release=lambda *_: s.choose_photo())
        status_btn.bind(on_release=lambda *_: s.edit_status())
        actions.add_widget(status_btn)
        actions.add_widget(photo_btn)
        page.add_widget(actions)

        scroll.add_widget(page)
        root.add_widget(scroll)
        root.add_widget(self.bottom_nav("profile"))
        s.add_widget(root)
        return s

    # ───────────────────────── المحظورون / الخصوصية / الإبلاغ ─────────────────────────
    def make_blocked(self):
        s = BlockedUsersScreen(name="blocked")
        root = self.base_root()
        root.add_widget(self.header("المستخدمون المحظورون", lambda: s.go("settings")))
        scroll = ScrollView(do_scroll_x=False, bar_width=dp(3))
        box = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(8))
        box.bind(minimum_height=box.setter("height"))
        s.ids.blocked_list = box
        scroll.add_widget(box)
        root.add_widget(scroll)
        s.add_widget(root)
        return s

    def make_privacy(self):
        s = PrivacyScreen(name="privacy")
        root = self.base_root()
        root.add_widget(self.header("الخصوصية والأمان", lambda: s.go("settings")))
        scroll = ScrollView(do_scroll_x=False, bar_width=dp(3))
        box = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(8))
        box.bind(minimum_height=box.setter("height"))
        for title, sub, icon in [
            ("آخر ظهور", "التحكم بظهور وقت اتصالك", "eye"),
            ("الصورة الشخصية", "من يستطيع رؤية صورتك", "user"),
            ("الحالة", "من يستطيع رؤية حالتك", "info"),
            ("إيصالات القراءة", "إظهار حالة قراءة الرسائل", "shield"),
        ]:
            box.add_widget(ActionRow(title, sub, icon=icon))
        note = self.label(
            "ملاحظة: حفظ خيارات الخصوصية يحتاج أعمدة إعدادات في profiles أو جدول preferences.",
            13, MUTED, halign="right", size_hint_y=None, height=dp(70))
        box.add_widget(note)
        scroll.add_widget(box)
        root.add_widget(scroll)
        s.add_widget(root)
        return s

    def make_report(self):
        s = ReportScreen(name="report")
        root = self.base_root()
        root.add_widget(self.header("الإبلاغ", lambda: s.go("chat")))
        intro = Card(orientation="horizontal", size_hint_y=None, height=dp(70),
                     padding=[dp(16), dp(10)], spacing=dp(12), fill=CARD, radius=20)
        intro.add_widget(self.label("اختر سبب الإبلاغ عن المستخدم", 16, TEXT, halign="right"))
        intro.add_widget(anchor(
            IconChip("flag", color=ACCENT, bg=(ACCENT[0], ACCENT[1], ACCENT[2], .16)), dp(44)))
        root.add_widget(intro)
        for reason in ["إساءة أو مضايقة", "محتوى مزعج", "انتحال شخصية", "محتوى غير مناسب", "سبب آخر"]:
            b = DarkButton(text=reason, size_hint_y=None, height=dp(54))
            b.bind(on_release=lambda _, r=reason: s.submit(r))
            root.add_widget(b)
        root.add_widget(Widget())
        s.add_widget(root)
        return s

    # ───────────────────────── المستخدمون / الإعدادات ─────────────────────────
    def make_users(self):
        s = UsersScreen(name="users")
        root = self.base_root()
        root.add_widget(self.header("المستخدمون", lambda: s.go("home")))
        scroll = ScrollView(do_scroll_x=False, bar_width=dp(3),
                            bar_color=(ACCENT[0], ACCENT[1], ACCENT[2], .5))
        box = BoxLayout(orientation="vertical", size_hint_y=None,
                        spacing=dp(8), padding=[0, dp(2), 0, dp(6)])
        box.bind(minimum_height=box.setter("height"))
        s.ids.users_list = box
        scroll.add_widget(box)
        root.add_widget(scroll)
        root.add_widget(self.bottom_nav("users"))
        s.add_widget(root)
        return s

    def make_settings(self):
        s = SettingsScreen(name="settings")
        root = self.base_root()
        root.add_widget(self.header("الإعدادات", lambda: s.go("home")))

        scroll = ScrollView(do_scroll_x=False, bar_width=dp(3))
        box = BoxLayout(
            orientation="vertical", size_hint_y=None, spacing=dp(8),
            padding=[0, dp(2), 0, dp(12)]
        )
        box.bind(minimum_height=box.setter("height"))

        sections = [
            ("الحساب", "تعديل الملف الشخصي والصورة والحالة", "user", lambda *_: s.profile()),
            ("الخصوصية والأمان", "آخر ظهور، إيصالات القراءة والحظر", "shield", lambda *_: s.privacy()),
            ("المستخدمون المحظورون", "عرض وإلغاء حظر المستخدمين", "block", lambda *_: s.blocked()),
            ("الإشعارات", "تنبيهات الرسائل والتحديثات", "bell", lambda *_: self.notice("إعدادات الإشعارات قيد الربط بالنظام.")),
            ("المظهر", "الوضع الداكن وحجم الواجهة", "moon", lambda *_: self.notice("المظهر الداكن مفعل حالياً.")),
            ("المحادثات والوسائط", "الصور والفيديو والملفات والرسائل", "image", lambda *_: self.notice("واجهة الوسائط مضافة، وربط التخزين يتم عبر Storage.")),
            ("حول AL WARD", "نسخة التطبيق ومعلومات المشروع", "info", lambda *_: self.notice("AL WARD — تطبيق دردشة عربي.")),
        ]

        for title, sub, icon, callback in sections:
            b = ActionRow(title, sub, icon=icon)
            b.bind(on_release=callback)
            box.add_widget(b)

        logout = DarkButton(
            text="تسجيل الخروج", size_hint_y=None, height=dp(56),
            fill=DANGER_FILL, border=DANGER_BORDER, color=DANGER_TXT,
            font_size="16sp"
        )
        logout.bind(on_release=lambda *_: s.logout())
        box.add_widget(Widget(size_hint_y=None, height=dp(6)))
        box.add_widget(logout)

        scroll.add_widget(box)
        root.add_widget(scroll)
        root.add_widget(self.bottom_nav("settings"))
        s.add_widget(root)
        return s

    # ───────────────────────── الترويسة والتنقل السفلي ─────────────────────────
    def header(self, title, back):
        box = BoxLayout(size_hint_y=None, height=dp(58), spacing=dp(8))
        box.add_widget(Widget(size_hint_x=None, width=dp(44)))
        box.add_widget(self.label(title, 21, TEXT))
        b = IconButton("back", color=TEXT, bg=CARD2)
        b.bind(on_release=lambda *_: back())
        box.add_widget(anchor(b, dp(44)))
        return box

    def bottom_nav(self, active):
        nav = Card(size_hint_y=None, height=dp(68), spacing=dp(4),
                   padding=[dp(6), dp(5)], fill=PANEL, radius=26)
        # من اليسار لليمين: الإعدادات، الملف، المستخدمون، المحادثات (الرئيسية أقصى اليمين)
        items = [
            ('الإعدادات', 'settings', 'sliders'),
            ('الملف الشخصي', 'profile', 'user'),
            ('المستخدمون', 'users', 'users'),
            ('المحادثات', 'home', 'chat'),
        ]
        for title, target, icon in items:
            item = NavItem(title, icon, active=(target == active))
            item.bind(on_release=lambda _, t=target: self.goto(t))
            nav.add_widget(item)
        return nav

    def goto(self, target):
        self.root.current = target

    # ───────────────────────── الجلسة الدائمة ─────────────────────────
    def _refresh_request(self):
        rt = self.local.get("refresh_token")
        if not rt:
            return None
        r = requests.post(
            SUPABASE_URL + "/auth/v1/token?grant_type=refresh_token",
            headers=headers(), json={"refresh_token": rt}, timeout=15,
        )
        if r.status_code != 200:
            return None
        return r.json()

    def refresh_session(self):
        """يجدد مفتاح الدخول قبل انتهائه (ساعة واحدة افتراضياً في Supabase)."""
        try:
            data = self._refresh_request()
        except Exception as exc:
            print("Token refresh error:", exc)
            return False
        if not data:
            return False
        self.token = data["access_token"]
        if data.get("refresh_token"):
            self.local["refresh_token"] = data["refresh_token"]
            save_local(self.local)
        self.token_time = time.time()
        return True

    def start_token_refresh(self):
        self.stop_token_refresh()
        self.token_time = time.time()
        self.token_event = Clock.schedule_interval(
            lambda dt: run_bg(self.refresh_session), 40 * 60)

    def stop_token_refresh(self):
        ev = getattr(self, "token_event", None)
        if ev is not None:
            ev.cancel()
        self.token_event = None

    def on_start(self):
        """استرجاع الجلسة السابقة تلقائياً بدون إعادة تسجيل الدخول."""
        if not (self.local.get("refresh_token") and self.local.get("username")):
            return
        busy = self.busy("جاري تسجيل الدخول...")

        def work():
            data = self._refresh_request()
            if not data:
                return False
            self.token = data["access_token"]
            self.user_id = data["user"]["id"]
            self.username = self.local.get("username")
            if data.get("refresh_token"):
                self.local["refresh_token"] = data["refresh_token"]
                save_local(self.local)
            self.ensure_profile()
            self.load_my_avatar()
            return True

        def done(ok, err):
            busy.dismiss()
            if ok:
                self.start_presence()
                self.start_token_refresh()
                self.root.current = "home"

        run_bg(work, done)

    def on_pause(self):
        return True

    def on_resume(self):
        if self.token and time.time() - getattr(self, "token_time", 0) > 20 * 60:
            run_bg(self.refresh_session)

    def sync_status(self, value):
        """يحفظ الحالة الشخصية على السيرفر ليراها الآخرون."""
        def work():
            r = requests.patch(
                SUPABASE_URL + "/rest/v1/profiles?id=eq." + str(self.user_id),
                headers={**headers(self.token), "Prefer": "return=minimal"},
                json={"status": value}, timeout=15)
            if r.status_code not in (200, 204):
                print("Status sync failed:", r.text)

        run_bg(work)

    def busy(self, message):
        box = BoxLayout(padding=dp(16))
        box.add_widget(self.label(message, 15, TEXT))
        pop = StyledPopup(title=ar("AL WARD"), content=box,
                          size_hint=(.8, .26), auto_dismiss=False)
        pop.open()
        return pop

    def load_my_avatar(self):
        """يجلب صورتي وحالتي من السيرفر، ويفصل بيانات الجهاز بين الحسابات."""
        if not self.token or not self.user_id:
            return
        if self.local.get("owner") != str(self.user_id):
            self.local["owner"] = str(self.user_id)
            self.local["avatar"] = ""
            self.local["avatar_url"] = ""
            self.local["status"] = "..."
        try:
            base = SUPABASE_URL + "/rest/v1/profiles?id=eq." + str(self.user_id) + "&select="
            r = requests.get(base + "avatar_url,status", headers=headers(self.token), timeout=12)
            if r.status_code == 400:
                r = requests.get(base + "avatar_url", headers=headers(self.token), timeout=12)
            if r.status_code == 200 and r.json():
                row = r.json()[0]
                self.local["avatar_url"] = row.get("avatar_url") or ""
                if row.get("status"):
                    self.local["status"] = row["status"]
        except Exception as exc:
            print("Profile load error:", exc)
        save_local(self.local)

    def ensure_profile(self):
        if not self.token or not self.user_id:
            return
        try:
            requests.post(
                SUPABASE_URL + "/rest/v1/profiles?on_conflict=id",
                headers={
                    **headers(self.token),
                    "Prefer": "resolution=merge-duplicates,return=minimal",
                },
                json={"id": self.user_id, "username": self.username},
                timeout=15,
            )
        except Exception as exc:
            print("Profile ensure error:", exc)

    def is_online(self, last_seen):
        if not last_seen:
            return False
        try:
            seen = datetime.fromisoformat(
                str(last_seen).replace("Z", "+00:00")
            )
            if seen.tzinfo is None:
                seen = seen.replace(tzinfo=timezone.utc)
            age = (
                datetime.now(timezone.utc) -
                seen.astimezone(timezone.utc)
            ).total_seconds()
            return 0 <= age <= 120
        except Exception:
            return False

    def start_presence(self):
        self.stop_presence()
        self.update_presence()
        self.presence_event = Clock.schedule_interval(
            lambda dt: self.update_presence(), 60
        )

    def stop_presence(self):
        if self.presence_event:
            self.presence_event.cancel()
            self.presence_event = None

    def update_presence(self):
        if not self.token or not self.user_id:
            return
        try:
            requests.patch(
                SUPABASE_URL + "/rest/v1/profiles?id=eq." + str(self.user_id),
                headers={
                    **headers(self.token),
                    "Prefer": "return=minimal",
                },
                json={"last_seen": datetime.now(timezone.utc).isoformat()},
                timeout=12,
            )
        except Exception as exc:
            print("Presence error:", exc)

    def logout(self):
        self.stop_presence()
        self.stop_token_refresh()
        self.local["refresh_token"] = ""
        save_local(self.local)
        self.token = None
        self.user_id = None
        self.username = None
        self.root.current = "login"

    def error(self, message):
        self.popup(message, "حصل خطأ")

    def notice(self, message):
        self.popup(message, "AL WARD")

    def popup(self, message, title):
        box = BoxLayout(orientation="vertical", padding=dp(16), spacing=dp(14))
        lbl = self.label(str(message), 15, TEXT)
        lbl.bind(size=lambda w, v: setattr(w, "text_size", v))
        box.add_widget(lbl)
        ok = GoldButton(text="حسناً", size_hint_y=None, height=dp(48))
        box.add_widget(ok)
        pop = StyledPopup(
            title=ar(title), content=box,
            size_hint=(.90, .42), auto_dismiss=False
        )
        ok.bind(on_release=pop.dismiss)
        pop.open()


if __name__ == "__main__":
    ALWardApp().run()
