[app]
p4a.branch = master
title = AL WARD
package.name = alward
package.domain = app.alward
source.dir = .
source.include_exts = py,png,jpg,ttf,json
version = 2.0

# python-bidi مثبّت على نسخة بايثون الصرفة لأن الجديدة تحتاج Rust وتفشل في البناء
requirements = python3,kivy==2.3.0,requests,urllib3,chardet,idna,certifi,charset-normalizer,arabic-reshaper,future,python-bidi==0.4.2,pillow,pyjnius,android,androidstorage4kivy

orientation = portrait
fullscreen = 0
presplash.color = #07050D

android.permissions = INTERNET,RECORD_AUDIO,CAMERA,READ_MEDIA_IMAGES,READ_EXTERNAL_STORAGE
android.api = 34
android.minapi = 24
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True
android.enable_androidx = True
android.gradle_dependencies = androidx.core:core:1.6.0

# icon.filename = %(source.dir)s/icon.png
# presplash.filename = %(source.dir)s/presplash.png

[buildozer]
log_level = 2
warn_on_root = 1
